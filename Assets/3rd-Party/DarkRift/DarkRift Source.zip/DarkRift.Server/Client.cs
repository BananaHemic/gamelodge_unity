﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;

using System.Threading;
using System.Net.Sockets;
using DarkRift.Dispatching;

namespace DarkRift.Server
{
    /// <inheritDoc />
    sealed class Client : IClient, IDisposable
    {
        /// <inheritdoc/>
        public event EventHandler<MessageReceivedEventArgs> MessageReceived;

#if PRO
        /// <inheritdoc/>
        public event EventHandler<StrikeEventArgs> StrikeOccured;
#endif

        /// <inheritdoc/>
        public ushort ID { get; }

        /// <inheritdoc/>
        public IPEndPoint RemoteTcpEndPoint => connection.GetRemoteEndPoint("tcp");

        /// <inheritdoc/>
        public IPEndPoint RemoteUdpEndPoint => connection.GetRemoteEndPoint("udp");

        /// <inheritdoc/>
        [Obsolete("Use Client.ConnectionState instead.")]
        public bool IsConnected => connection.ConnectionState == ConnectionState.Connected;

        /// <inheritdoc/>
        public ConnectionState ConnectionState => connection.ConnectionState;

        /// <inheritdoc/>
        public byte Strikes
        {
            get
            {
                return (byte)Thread.VolatileRead(ref strikes);
            }
#if PRO
            set
            {
                Interlocked.Exchange(ref strikes, value);
            }
#endif

        }
        int strikes;

        /// <inheritdoc/>
#if PRO
        public
#else
        internal
#endif
            DateTime ConnectionTime { get; }

        /// <inheritdoc/>
#if PRO
        public
#else
        internal
#endif
        uint MessagesSent => (uint)Thread.VolatileRead(ref messagesSent);
        int messagesSent;

        /// <inheritdoc/>
#if PRO
        public
#else
        internal
#endif
        uint MessagesPushed => (uint)Thread.VolatileRead(ref messagesPushed);
        int messagesPushed;

        /// <inheritdoc/>
#if PRO
        public
#else
        internal
#endif
        uint MessagesReceived => (uint)Thread.VolatileRead(ref messagesReceived);
        int messagesReceived;

        /// <inheritdoc/>
        public IEnumerable<IPEndPoint> RemoteEndPoints => connection.RemoteEndPoints;

        /// <summary>
        ///     The connection to the client.
        /// </summary>
        NetworkServerConnection connection;

        /// <summary>
        ///     The server we belong to.
        /// </summary>
        DarkRiftServer server;

        /// <summary>
        ///     Creates a new client connection with a given global identifier and the client they are connected through.
        /// </summary>
        /// <param name="connection">The connection we handle.</param>
        /// <param name="id">The ID assigned to this client.</param>
        /// <param name="server">The server we belong to.</param>
        internal Client(NetworkServerConnection connection, ushort id, DarkRiftServer server)
        {
            this.server = server;
            this.connection = connection;
            this.ID = id;

            this.ConnectionTime = DateTime.Now;

            connection.MessageReceived = HandleIncomingDataBuffer;
            connection.Disconnected = Disconnected;
        }

        /// <summary>
        ///     Sends the client their ID.
        /// </summary>
        internal void SendID()
        {
            using (DarkRiftWriter writer = DarkRiftWriter.Create())
            {
                writer.Write(ID);

                using (Message command = Message.Create((ushort)CommandCode.Configure, writer))
                {
                    command.IsCommandMessage = true;
                    PushBuffer(command.ToBuffer(), SendMode.Reliable);
                }
            }
        }

        /// <inheritdoc/>
        public bool SendMessage(Message message, SendMode sendMode)
        {
            //Send frame
            if (!PushBuffer(message.ToBuffer(), sendMode))
                return false;

            //Increment counter
            Interlocked.Increment(ref messagesSent);

            return true;
        }

        /// <inheritdoc/>
        public bool Disconnect()
        {
            if (!connection.Disconnect())
                return false;

            server.InternalClientManager.HandleDisconnection(this, true, SocketError.Disconnecting, null);

            return true;
        }
        
        /// <inheritdoc/>
        public IPEndPoint GetRemoteEndPoint(string name)
        {
            return connection.GetRemoteEndPoint(name);
        }

        /// <summary>
        ///     Handles a remote disconnection.
        /// </summary>
        /// <param name="error">The error that caused the disconnection.</param>
        /// <param name="exception">The exception that caused the disconnection.</param>
        void Disconnected(SocketError error, Exception exception)
        {
            server.InternalClientManager.HandleDisconnection(this, false, error, exception);
        }

        /// <summary>
        ///     Handles data that was sent from this client.
        /// </summary>
        /// <param name="buffer">The buffer that was received.</param>
        /// <param name="sendMode">The method data was sent using.</param>
        internal void HandleIncomingDataBuffer(MessageBuffer buffer, SendMode sendMode)
        {
            //Add to received message counter
            Interlocked.Increment(ref messagesReceived);

            Message message;
            try
            {
                message = Message.Create(buffer, false);
            }
            catch (IndexOutOfRangeException)
            {
                Strike(StrikeReason.InvalidMessageLength, "The message received was not long enough to contain the header.");
                return;
            }

            HandleIncomingMessage(message, sendMode);
        }

        /// <summary>
        ///     Handles messages that were sent from this client.
        /// </summary>
        /// <param name="message">The message that was received.</param>
        /// <param name="sendMode">The method data was sent using.</param>
        internal void HandleIncomingMessage(Message message, SendMode sendMode)
        {
            //Discard any command messages sent from the client since they shouldn't send them
            if (message.IsCommandMessage)
            {
                Strike(StrikeReason.InvalidCommand, "Received an command message from the client that was not accepted by the server.");
                return;
            }

            MessageReceivedEventArgs args = new MessageReceivedEventArgs(
                message,
                sendMode,
                this
            );
            
            //Inform plugins
            server.ThreadHelper.DispatchIfNeeded(
                delegate ()
                {
                    try
                    {
                        MessageReceived?.Invoke(this, args);
                    }
                    catch (Exception e)
                    {
                        server.InternalLogManager.WriteEvent(
                            nameof(Client),
                            ErrorStrings.MESSAGERECEIVIED_PLUGIN_EXCEPTION,
                            LogType.Error,
                            e
                        );
                    }
                }
            );
        }

        /// <summary>
        ///     Pushes a buffer to the client.
        /// </summary>
        /// <param name="buffer">The buffer to push.</param>
        /// <param name="sendMode">The method to send the data using.</param>
        /// <returns>Whether the send was successful.</returns>
        bool PushBuffer(MessageBuffer buffer, SendMode sendMode)
        {
            if (!connection.SendMessage(buffer, sendMode))
                return false;

            Interlocked.Increment(ref messagesPushed);

            return true;
        }

#region Strikes

#if PRO
        /// <inheritdoc/>
        public void Strike(string message = null)
        {
            Strike(StrikeReason.PluginRequest, message);
        }
#endif

        /// <summary>
        ///     Informs plugins and adds a strike to this client's record.
        /// </summary>
        /// <param name="reason">The reason for the strike.</param>
        /// <param name="message">A message describing the reason for the strike.</param>
        internal void Strike(StrikeReason reason, string message = null)
        {
#if PRO
            EventHandler<StrikeEventArgs> handler = StrikeOccured;
            if (handler != null)
            {
                StrikeEventArgs args = new StrikeEventArgs(reason, message);

                if (server.EventsFromDispatcher)
                {
                    server.Dispatcher.InvokeAsync(
                        delegate ()
                        {
                            try
                            {
                                handler.Invoke(this, args);
                            }
                            catch (Exception e)
                            {
                                server.InternalLogManager.WriteEvent(
                                    nameof(Client),
                                    ErrorStrings.STRIKEOCCURED_PLUGIN_EXCEPTION,
                                    LogType.Error,
                                    e
                                );
                            }
                        },
                        delegate (ActionDispatcherTask t)
                        {
                            if (t.Exception == null)
                            {
                                if (args.Forgiven)
                                    return;
                            }

                            EnforceStrike(reason, message);
                        }
                    );
                }
                else
                {
                    try
                    {
                        handler.Invoke(this, args);

                        if (args.Forgiven)
                            return;
                    }
                    catch (Exception e)
                    {
                        server.InternalLogManager.WriteEvent(
                            nameof(Client),
                            ErrorStrings.STRIKEOCCURED_PLUGIN_EXCEPTION,
                            LogType.Error,
                            e
                        );
                    }

                    EnforceStrike(reason, message);
                }
            }
#else
            EnforceStrike(reason, message);
#endif
        }

        /// <summary>
        ///     Adds a strike to this client's record.
        /// </summary>
        /// <param name="reason">The reason for the strike.</param>
        /// <param name="message">A message describing the reason for the strike.</param>
        void EnforceStrike(StrikeReason reason, string message)
        {
            Interlocked.Increment(ref strikes);

            server.InternalLogManager.WriteEvent(
                nameof(Client),
                $"Client received strike for {reason} {(message == null ? "" : ": " + message)}.",
                LogType.Trace
            );

            if (strikes == server.ClientManager.MaxStrikes)
            {
                Disconnect();

                server.InternalLogManager.WriteEvent(
                    nameof(Client),
                    "Client was disconnected as they accumulated too many strikes.",
                    LogType.Trace
                );
            }
        }
#endregion

        /// <summary>
        ///     Disposes of this client.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

#pragma warning disable CS0628
        protected void Dispose(bool disposing)
        {
            if (disposing)
                connection.Dispose();
        }
#pragma warning restore CS0628
    }
}
