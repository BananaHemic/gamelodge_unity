﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace DarkRift.Server
{
    /// <summary>
    ///     Helper class for reading XML configuration files.
    /// </summary>
    class ConfigurationFileHelper
    {
        /// <summary>
        ///     The variables to inject into configuration.
        /// </summary>
        internal NameValueCollection Variables { get; }

        /// <summary>
        ///     Creates a new helper with the specified variables.
        /// </summary>
        /// <param name="variables"></param>
        internal ConfigurationFileHelper(NameValueCollection variables)
        {
            this.Variables = variables;
        }

        /// <summary>
        ///     Reads an IP attribute from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="missingErrorString">The message string when the attribute is missing.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <returns>The IP address read.</returns>
        internal IPAddress ReadIPAttribute(XElement element, string attributeName, string missingErrorString, string invalidErrorString)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                throw new XmlConfigurationException(missingErrorString);

            string value = ResolveVariables(attribute.Value);

            try
            {
                return IPAddress.Parse(value);
            }
            catch (Exception e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads an IP attribute from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <param name="defaultValue">The default value if none is provided.</param>
        /// <returns>The IP address read.</returns>
        internal IPAddress ReadIPAttributeOrDefault(XElement element, string attributeName, string invalidErrorString, IPAddress defaultValue)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                return defaultValue;

            string value = ResolveVariables(attribute.Value);

            try
            {
                return IPAddress.Parse(value);
            }
            catch (Exception e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads an IP version value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="missingErrorString">The message string when the attribute is missing.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <returns>The ip version read.</returns>
        internal IPVersion ReadIPVersionAttribute(XElement element, string attributeName, string missingErrorString, string invalidErrorString)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                throw new XmlConfigurationException(missingErrorString);

            if (ResolveVariables(attribute.Value).ToLower() == "ipv4")
                return IPVersion.IPv4;
            else if (attribute.Value.ToLower() == "ipv6")
                return IPVersion.IPv6;
            else
                throw new XmlConfigurationException(invalidErrorString);
        }

        /// <summary>
        ///     Reads an IP version value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <param name="defaultValue">The default value if none is provided.</param>
        /// <returns>The ip version read.</returns>
        internal IPVersion ReadIPVersionAttributeOrDefault(XElement element, string attributeName, string invalidErrorString, IPVersion defaultValue)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                return defaultValue;

            if (ResolveVariables(attribute.Value).ToLower() == "ipv4")
                return IPVersion.IPv4;
            else if (attribute.Value.ToLower() == "ipv6")
                return IPVersion.IPv6;
            else
                throw new XmlConfigurationException(invalidErrorString);
        }

        /// <summary>
        ///     Reads a Boolean value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <param name="defaultValue">The default value to return if the attribute isn't present.</param>
        /// <returns>The Boolean read.</returns>
        internal bool ReadBooleanAttribute(XElement element, string attributeName, string invalidErrorString, bool defaultValue)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                return defaultValue;

            string value = ResolveVariables(attribute.Value);

            try
            {
                return XmlConvert.ToBoolean(value);
            }
            catch (FormatException e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads a byte value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="missingErrorString">The message string when the attribute is missing.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <returns>The byte read.</returns>
        internal byte ReadByteAttribute(XElement element, string attributeName, string missingErrorString, string invalidErrorString)
        {
            var attribute = element.Attribute(attributeName);
            if (attribute == null)
                throw new XmlConfigurationException(missingErrorString);

            string value = ResolveVariables(attribute.Value);

            try
            {
                return XmlConvert.ToByte(value);
            }
            catch (Exception e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads a UInt16 value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="missingErrorString">The message string when the attribute is missing.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <returns>The UInt16 read.</returns>
        internal ushort ReadUInt16Attribute(XElement element, string attributeName, string missingErrorString, string invalidErrorString)
        {
            var attribute = element.Attribute(attributeName);
            if (attribute == null)
                throw new XmlConfigurationException(missingErrorString);

            string value = ResolveVariables(attribute.Value);

            try
            {
                return XmlConvert.ToUInt16(value);
            }
            catch (Exception e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads a UInt16 value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <param name="defaultValue">The default value to return if the attribute isn't present.</param>
        /// <returns>The UInt16 read.</returns>
        internal ushort ReadUInt16AttributeOrDefault(XElement element, string attributeName, string invalidErrorString, ushort defaultValue)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                return defaultValue;

            string value = ResolveVariables(attribute.Value);

            try
            {
                return XmlConvert.ToUInt16(value);
            }
            catch (Exception e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads a UInt32 value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="invalidErrorString">The message string when the attribute is invalid.</param>
        /// <param name="defaultValue">The default value to return if the attribute isn't present.</param>
        /// <returns>The UInt32 read.</returns>
        internal uint ReadUInt32AttributeOrDefault(XElement element, string attributeName, string invalidErrorString, uint defaultValue)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                return defaultValue;

            string value = ResolveVariables(attribute.Value);

            try
            {
                return XmlConvert.ToUInt32(value);
            }
            catch (FormatException e)
            {
                throw new XmlConfigurationException(invalidErrorString, e);
            }
        }

        /// <summary>
        ///     Reads a string value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="missingErrorString">The message string when the attribute is missing.</param>
        /// <returns>The string read.</returns>
        internal string ReadStringAttribute(XElement element, string attributeName, string missingErrorString)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                throw new XmlConfigurationException(missingErrorString);

            return ResolveVariables(attribute.Value);
        }

        /// <summary>
        ///     Reads a string value from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="attributeName">The name of the attribute to read.</param>
        /// <param name="defaultValue">The default value to return if the attribute isn't present.</param>
        /// <returns>The string read.</returns>
        internal string ReadStringAttributeOrDefault(XElement element, string attributeName, string defaultValue)
        {
            var attribute = element.Attribute(attributeName);

            if (attribute == null)
                return defaultValue;

            return ResolveVariables(attribute.Value);
        }

        /// <summary>
        ///     Reads a collection of attributes from the XML element supplied.
        /// </summary>
        /// <param name="element">The element to read from.</param>
        /// <param name="collection">The collection to read into.</param>
        internal void ReadAttributeCollectionTo(XElement element, NameValueCollection collection)
        {
            if (element == null)
                return;

            foreach (var attribute in element.Attributes())
                collection.Add(attribute.Name.LocalName, ResolveVariables(attribute.Value));
        }

        /// <summary>
        ///     Reads a collection of elements from the XML element supplied.
        /// </summary>
        /// <typeparam name="T">The type of the elements to read.</typeparam>
        /// <param name="element">The element to read from.</param>
        /// <param name="elementName">The name of the child elements to parse.</param>
        /// <param name="parseFunction">The function to parse each child element.</param>
        /// <param name="collection">The collection to write the elements to.</param>
        internal void ReadElementCollectionTo<T>(XElement element, string elementName, Func<XElement, T> parseFunction, ICollection<T> collection)
        {
            var results = element.Elements(elementName).Select(parseFunction);

            foreach (var result in results)
                collection.Add(result);
        }

        /// <summary>
        ///     Resolves variables to their values in the given string.
        /// </summary>
        /// <param name="str">The string to resolve variables in.</param>
        /// <returns>The resolved string.</returns>
        internal string ResolveVariables(string str)
        {
            Regex pattern = new Regex(@"\$\((\w+)\)");

            Match match;
            while ((match = pattern.Match(str)).Success)
            {
                string key = match.Groups[1].Value;
                string value = Variables[key];

                if (value == null)
                    throw new KeyNotFoundException("Unable to find variable for '" + key + "'.");

                str = str.Substring(0, match.Index) + value + str.Substring(match.Index + match.Length);
            }

            return str;
        }
    }
}
