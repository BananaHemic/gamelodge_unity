﻿using DarkRift.Dispatching;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Data related to the plugin's loading.
    /// </summary>
    public sealed class PluginLoadData : ExtendedPluginBaseLoadData
    {
        /// <summary>
        ///     The client manager to pass to the server.
        /// </summary>
        public IClientManager ClientManager { get; set; }
        
        /// <summary>
        ///     The plugin manager to pass to the plugin.
        /// </summary>
        public IPluginManager PluginManager { get; set; }

        /// <summary>
        ///     The network listener manager to pass to the plugin.
        /// </summary>
        public INetworkListenerManager NetworkListenerManager { get; set; }
        
        /// <summary>
        ///     The resource directory to pass to the plugin.
        /// </summary>
        public string ResourceDirectory { get; set; }

        internal PluginLoadData (string name, DarkRiftServer server, NameValueCollection settings, WriteEventHandler writeEventHandler, string resourceDirectory)
            : base(name, server, settings, writeEventHandler)
        {
            this.ClientManager = server.ClientManager;
            this.PluginManager = server.PluginManager;
            this.NetworkListenerManager = server.NetworkListenerManager;
            this.ResourceDirectory = resourceDirectory;
        }

        public PluginLoadData(string name, NameValueCollection settings, DarkRiftInfo serverInfo, DarkRiftThreadHelper threadHelper, WriteEventHandler writeEventHandler, string resourceDirectory)
            : base(name, settings, serverInfo, threadHelper, writeEventHandler)
        {
            this.ResourceDirectory = resourceDirectory;
        }
    }
}
