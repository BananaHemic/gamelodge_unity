﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;
using DarkRift.Server.Plugins.Listeners.Bichannel;
using DarkRift.Dispatching;

namespace DarkRift.Server
{
    /// <summary>
    ///     Handles all clients on the server.
    /// </summary>
    sealed class ClientManager : IDisposable, IClientManager
    {
        /// <summary>
        ///     The address the server is listening on.
        /// </summary>
        [Obsolete("Use listener system instead. This will currently read the address of a BichannelListener called 'Default'.")]
        public IPAddress Address => GetDefaultBichannelListenerOrError().Address;

        /// <summary>
        ///     The port the server is listening on.
        /// </summary>
        [Obsolete("Use listener system instead. This will currently read the port of a BichannelListener called 'Default'.")]
        public ushort Port => (ushort)GetDefaultBichannelListenerOrError().Port;
            
        /// <summary>
        ///     The IP version that the server is listening on.
        /// </summary>
        [Obsolete("Use listener system instead. This will currently read the IP version of a BichannelListener called 'Default'.")]
        public IPVersion IPVersion => GetDefaultBichannelListenerOrError().IPVersion;

        /// <summary>
        ///     Whether Nagle's algorithm is disabled.
        /// </summary>
        [Obsolete("Use listener system instead. This will currently read the no delay property of a BichannelListener called 'Default'.")]
        public bool NoDelay => GetDefaultBichannelListenerOrError().NoDelay;

        /// <summary>
        ///     Returns whether the server has been started and not yet stopped.
        /// </summary>
        public bool Listening { get; private set; }

        /// <summary>
        ///     Invoked when a client connects to the server.
        /// </summary>
        public event EventHandler<ClientConnectedEventArgs> ClientConnected;

        /// <summary>
        ///     Invoked when a client disconnects from the server.
        /// </summary>
        public event EventHandler<ClientDisconnectedEventArgs> ClientDisconnected;
        
        /// <summary>
        ///     Returns the number of clients currently connected.
        /// </summary>
        public int Count
        {
            get
            {
                lock (clients)
                    return clients.Count;
            }
        }

        /// <summary>
        ///     The number of strikes a client can get before they are kicked.
        /// </summary>
        public byte MaxStrikes { get; }

        /// <summary>
        ///     Whether the fallback networking is being used for compatability.
        /// </summary>
        /// <remarks>
        ///     Unity has issues with DarkRift's default (better) socket interfaces so this indicates
        ///     the fallback networking is in use for compatability at a performance cost.
        /// </remarks>
        [Obsolete("Use listener system instead. This will currently read if a BichannelListener or CompatibilityBichannelListener is called 'Default'.")]
        public bool UseFallbackNetworking => GetDefaultBichannelListenerOrError() is CompatibilityBichannelListener;

        /// <summary>
        ///     The clients connected to this server.
        /// </summary>
        Dictionary<ushort, Client> clients = new Dictionary<ushort, Client>();

        /// <summary>
        ///     The server instance owning us.
        /// </summary>
        DarkRiftServer server;

        /// <summary>
        ///     The last ID allocated on this server
        /// </summary>
        ushort lastIDAllocated = ushort.MaxValue;       //Start at 0

        /// <summary>
        ///     The lock on ID allocation
        /// </summary>
        object idLockObj = new object();

        public ClientManager(DarkRiftServer serverInstance, ServerSpawnData.ServerSettings settings)
        {
            this.MaxStrikes = settings.MaxStrikes;
            
            this.server = serverInstance;
        }

        /// <summary>
        ///     Returns the Default BichannelListener if present or throws an exception.
        /// </summary>
        /// <returns>The default Bichannel listener.</returns>
        BichannelListenerBase GetDefaultBichannelListenerOrError()
        {
            NetworkListener listener = server.NetworkListenerManager.GetNetworkListenerByName("DefaultNetworkListener");
            if (listener == null)
                throw new InvalidOperationException("There is no listener named \"DefaultNetworkListener\", use the listener system to access this property instead.");

            BichannelListenerBase bListener = listener as BichannelListenerBase;
            if (bListener == null)
                throw new InvalidOperationException("The listener named \"DefaultNetworkListener\" is not a BichannelListener, use the listener system to access this property instead.");

            return bListener;
        }

        /// <summary>
        ///     Called when a new client connects.
        /// </summary>
        /// <param name="connection">The new client.</param>
        internal void HandleNewConnection(NetworkServerConnection connection)
        {
            //Allocate ID and add to list
            Client client;
            lock (idLockObj)
            {
                ushort toTest = lastIDAllocated;

                bool taken;
                do
                {
                    unchecked
                    {
                        toTest++;
                    }
                    
                    lock (clients)
                        taken = clients.ContainsKey(toTest);

                    //Check there are still ids to allocate!
                    if (toTest == lastIDAllocated)
                    {
                        server.InternalLogManager.WriteEvent(nameof(ClientManager), $"New client could not connect as there were no IDs available to allocate to them [{string.Join("|", connection.RemoteEndPoints.Select(r => r.ToString()).ToArray())}].", LogType.Info);
                        return;
                    }
                } while (taken);

                lastIDAllocated = toTest;

                client = new Client(
                    connection,
                    toTest,
                    server
                );

                connection.Client = client;

                lock (clients)
                    clients.Add(toTest, client);
            }

            server.InternalLogManager.WriteEvent(nameof(ClientManager), $"New client [{client.ID}] connected [{string.Join("|", connection.RemoteEndPoints.Select(r => r.ToString()).ToArray())}].", LogType.Info);

            client.SendID();

            //Inform plugins of the new connection
            EventHandler<ClientConnectedEventArgs> handler = ClientConnected;
            if (handler != null)
            {
                server.ThreadHelper.DispatchIfNeeded(
                    delegate ()
                    {
                        try
                        {
                            handler?.Invoke(this, new ClientConnectedEventArgs(client));
                        }
                        catch (Exception e)
                        {
                            server.InternalLogManager.WriteEvent(
                                nameof(ClientManager),
                                ErrorStrings.CLIENTCONNECTED_PLUGIN_EXCEPTION,
                                LogType.Error,
                                e
                            );

                            connection.Disconnect();
                        }
                    }
                );
            }

            connection.StartListening();
        }

        /// <summary>
        ///     Handles a client disconnecting. 
        /// </summary>
        /// <param name="client">The client disconnecting.</param>
        /// <param name="localDisconnect">If the disconnection was caused by a call to <see cref="Client.Disconnect"/></param>
        /// <param name="error">The error that caused the disconnect.</param>
        /// <param name="exception">The exception that caused the disconnect.</param>
        internal void HandleDisconnection(Client client, bool localDisconnect, SocketError error, Exception exception)
        {
            lock (clients)
                clients.Remove(client.ID);

            //Inform plugins of the disconnection
            EventHandler<ClientDisconnectedEventArgs> handler = ClientDisconnected;
            if (handler != null)
            {
                if (server.EventsFromDispatcher)
                {
                    server.Dispatcher.InvokeAsync(
                        delegate ()
                        {
                            try
                            {

                                handler?.Invoke(this, new ClientDisconnectedEventArgs(client, localDisconnect, error, exception));
                            }
                            catch (Exception e)
                            {
                                server.InternalLogManager.WriteEvent(
                                    nameof(ClientManager),
                                    ErrorStrings.CLIENTDISCONNECTED_PLUGIN_EXCEPTION,
                                    LogType.Error,
                                    e
                                );
                            }
                        },
                        delegate (ActionDispatcherTask t)
                        {
                            FinaliseClientDisconnect(exception, error, client);
                        }
                    );
                }
                else
                {
                    try
                    {
                        handler?.Invoke(this, new ClientDisconnectedEventArgs(client, localDisconnect, error, exception));
                    }
                    catch (Exception e)
                    {
                        server.InternalLogManager.WriteEvent(
                            nameof(ClientManager),
                            ErrorStrings.CLIENTDISCONNECTED_PLUGIN_EXCEPTION,
                            LogType.Error,
                            e
                        );
                    }

                    FinaliseClientDisconnect(exception, error, client);
                }
            }
        }

        /// <summary>
        ///     Finalises the client disconnecting.
        /// </summary>
        /// <param name="exception">The exception causing the disconnect.</param>
        /// <param name="error">The SocketError causing the disconnect.</param>
        /// <param name="client">The client disconnecting.</param>
        void FinaliseClientDisconnect(Exception exception, SocketError error, Client client)
        {
            if (exception == null && (error == SocketError.Success || error == SocketError.Disconnecting))
            {
                server.InternalLogManager.WriteEvent(nameof(ClientManager), $"Client [{client.ID}] disconnected.", LogType.Info);
            }
            else
            {
                string reason = error == SocketError.Success ? exception.Message : error.ToString();
                server.InternalLogManager.WriteEvent(nameof(ClientManager), $"Client [{client.ID}] disconnected: {reason}.", LogType.Info, exception);
            }

            client.Dispose();
        }

        /// <inheritdoc/>
        public IClient[] GetAllClients()
        {
            lock (clients)
                return clients.Values.ToArray();
        }

        /// <inheritdoc/>
        public IClient this[ushort id]
        {
            get
            {
                return GetClient(id);
            }
        }

        /// <inheritdoc/>
        public IClient GetClient(ushort id)
        {
            lock (clients)
                return clients[id];
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

#pragma warning disable CS0628
        protected void Dispose(bool disposing)
        {
            if (disposing)
            {
                lock (clients)
                {
                    foreach (Client connection in clients.Values)
                        connection.Dispose();
                }
            }
        }
#pragma warning restore CS0628
    }
}
