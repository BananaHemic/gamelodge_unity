﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;

using System.Data.Common;
using System.Collections.Specialized;
using System.Threading;

namespace DarkRift.Server
{
    /// <summary>
    ///     The manager of all plugins on the server.
    /// </summary>
    sealed class PluginManager : ExtendedPluginManagerBase<Plugin>, IPluginManager
    {
        /// <summary>
        ///     Creates a new PluginManager.
        /// </summary>
        /// <param name="server">The server that owns this plugin manager.</param>
        internal PluginManager(DarkRiftServer server)
            : base (server)
        {
        }

        /// <summary>
        ///     Loads the plugins found by the plugin factory.
        /// </summary>
        /// <param name="settings">The settings to load plugins with.</param>
        internal void LoadPlugins(ServerSpawnData.PluginsSettings settings)
        {
            Type[] types = Server.PluginFactory.GetAllSubtypes(typeof(Plugin));
            
            foreach (Type type in types)
            {
                var s = settings.Plugins.FirstOrDefault(p => p.Type == type.Name);

                PluginLoadData loadData = new PluginLoadData(
                    type.Name, 
                    Server, 
                    s?.Settings ?? new NameValueCollection(),
                    (message, logType, exception) => Server.InternalLogManager.WriteEvent(type.Name, message, logType, exception),
                    Server.DataManager.GetResourceDirectory(type.Name)
                );

                if (s?.Load ?? settings.LoadByDefault)
                    LoadPlugin(type.Name, type, loadData, null, true);
            }
        }

        /// <inheritdoc/>
        public Plugin this[string name]
        {
            get
            {
                return GetPlugin(name);
            }
        }

        /// <inheritdoc/>
        public Plugin GetPluginByName(string name)
        {
            return this[name];
        }

        /// <inheritdoc/>
        public T GetPluginByType<T>() where T : Plugin
        {
            return (T)(GetPlugins().First((x) => x is T));
        }

        /// <inheritdoc/>
        public Plugin[] GetAllPlugins()
        {
            return GetPlugins().Where((p) => !p.Hidden).ToArray();
        }

        /// <inheritdoc/>
        public Plugin[] ActuallyGetAllPlugins()
        {
            return GetPlugins().ToArray();
        }
    }
}
