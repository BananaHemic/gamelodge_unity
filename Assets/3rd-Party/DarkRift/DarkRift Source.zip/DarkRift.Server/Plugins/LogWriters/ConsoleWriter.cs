﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server.Plugins.LogWriters
{
    /// <summary>
    ///     Log writer that outputs to the console.
    /// </summary>
    public sealed class ConsoleWriter : LogWriter
    {
        /// <inheritdoc/>
        public override Version Version => new Version(1, 0, 0);
        
        //TODO 3 expose colours to settings
        
        /// <summary>
        ///     The lookup table for the foreground colors to print with.
        /// </summary>
        ConsoleColor[] ForegroundColours { get; }

        /// <summary>
        ///     The lookup table for the background colours to print with.
        /// </summary>
        ConsoleColor[] BackgroundColours { get; }

        /// <summary>
        ///     Lock for console writes.
        /// </summary>
        /// <remarks>
        ///     Technically, Console is thread safe but if we don't have this then colours get mixed up with fast writes.
        /// </remarks>
        Object consoleLock = new object();

        /// <summary>
        ///     Creates a new console writer with the plugins load data.
        /// </summary>
        /// <param name="logWriterLoadData">The data to load the logwriter with.</param>
        public ConsoleWriter(LogWriterLoadData logWriterLoadData) : base(logWriterLoadData)
        {
            ForegroundColours = new ConsoleColor[] { ConsoleColor.Gray, ConsoleColor.Gray, ConsoleColor.Yellow, ConsoleColor.Red, ConsoleColor.Red };
            BackgroundColours = new ConsoleColor[] { ConsoleColor.Black, ConsoleColor.Black, ConsoleColor.Black, ConsoleColor.Black, ConsoleColor.Gray };
        }

        /// <inheritdoc/>
        public override void WriteEvent(WriteEventArgs args)
        {
            lock (consoleLock)
            {
                //Set colours
                Console.ForegroundColor = ForegroundColours[(int)args.LogType];
                Console.BackgroundColor = BackgroundColours[(int)args.LogType];

                //Output
                if (args.LogType == LogType.Error)
                    Console.Error.WriteLine(args.FormattedMessage);
                else
                    Console.WriteLine(args.FormattedMessage);

                Console.ResetColor();
            }
        }
    }
}
