﻿#if PRO
namespace DarkRift.Server.Plugins.Matchmaking
{
    /// <summary>
    ///     The state of a matchmaking operation by a <see cref="Matchmaker{T, S}"/>.
    /// </summary>
    /// <remarks>
    ///     <c>Pro only.</c>
    /// </remarks>
    public enum MatchmakingState
    {
        /// <summary>
        ///     Indicates the matchmaking operation has not yet been passed to the matchmaker.
        /// </summary>
        Pending,

        /// <summary>
        ///     Indicates the matchmaking operation is queued in the matchmaker.
        /// </summary>
        Queued,

        /// <summary>
        ///     Indicates the matchmakign operation succeeded.
        /// </summary>
        Success,

        /// <summary>
        ///     Indicates the matchmaking operation was cancelled.
        /// </summary>
        Cancelled
    }
}
#endif
