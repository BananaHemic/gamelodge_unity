﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;

namespace DarkRift.Server.Plugins.Listeners.Bichannel
{
    /// <summary>
    ///     A connection to a remote cliente and handles TCP and UDP channels.
    /// </summary>
    sealed class BichannelServerConnection : NetworkServerConnection
    {
        /// <summary>
        ///     Is this client able to send or not.
        /// </summary>
        public bool CanSend { get; private set; }

        /// <summary>
        ///     Is this client currently listening for messages or not.
        /// </summary>
        public bool IsListening { get; private set; }

        /// <summary>
        ///     The end point of the remote client on TCP.
        /// </summary>
        public IPEndPoint RemoteTcpEndPoint { get; }

        /// <summary>
        ///     The end point of the remote client on UDP.
        /// </summary>
        public IPEndPoint RemoteUdpEndPoint { get; }
        
        /// <summary>
        ///     Whether Nagel's algorithm should be disabled or not.
        /// </summary>
        public bool NoDelay
        {
            get => tcpSocket.NoDelay;
            set
            {
                tcpSocket.NoDelay = value;
            }
        }

        /// <summary>
        ///     The token used to authenticate this user's UDP connection.
        /// </summary>
        public long AuthToken { get; }

        /// <inheritdoc/>
        public override ConnectionState ConnectionState => CanSend ? ConnectionState.Connected : ConnectionState.Disconnected;

        /// <inheritdoc/>
        public override IEnumerable<IPEndPoint> RemoteEndPoints => new IPEndPoint[2] { RemoteTcpEndPoint, RemoteUdpEndPoint };

        /// <summary>
        ///     The socket used in TCP communication.
        /// </summary>
        readonly Socket tcpSocket;

        /// <summary>
        ///     The listener used in UDP communication.
        /// </summary>
        readonly BichannelListenerBase networkListener;

        internal BichannelServerConnection(Socket tcpSocket, BichannelListenerBase networkListener, IPEndPoint udpEndPoint, long authToken)
        {
            this.tcpSocket = tcpSocket;
            this.networkListener = networkListener;
            this.RemoteTcpEndPoint = (IPEndPoint)tcpSocket.RemoteEndPoint;
            this.RemoteUdpEndPoint = udpEndPoint;
            this.AuthToken = authToken;
            
            //Mark connected to allow sending
            CanSend = true;
        }
        
        /// <summary>
        ///     Begins listening for data.
        /// </summary>
        public override void StartListening()
        {
            //Setup the TCP socket to receive a header
            SocketAsyncEventArgs tcpArgs = ObjectCache.GetSocketAsyncEventArgs();
            tcpArgs.BufferList = null;
            tcpArgs.SetBuffer(new byte[4], 0, 4);

            tcpArgs.Completed += TcpHeaderReceiveCompleted;

            bool tcpCompletingAsync = tcpSocket.ReceiveAsync(tcpArgs);
            if (!tcpCompletingAsync)
                TcpHeaderReceiveCompleted(this, tcpArgs);

            //Register for UDP Messages
            networkListener.RegisterUdpConnection(this);

            //Mark as listening
            IsListening = true;
        }

        /// <inheritdoc/>
        public override bool SendMessageReliable(MessageBuffer message)
        {
            if (!CanSend)
                return false;

            byte[] header = new byte[4];
            BigEndianHelper.WriteBytes(header, 0, message.Count);

            SocketAsyncEventArgs args = ObjectCache.GetSocketAsyncEventArgs();

            args.SetBuffer(null, 0, 0);
            args.BufferList = new List<ArraySegment<byte>>()
            {
                new ArraySegment<byte>(header),
                new ArraySegment<byte>(message.Buffer, message.Offset, message.Count)
            };
            args.UserToken = message;

            args.Completed += TcpSendCompleted;

            bool completingAsync = tcpSocket.SendAsync(args);
            if (!completingAsync)
                TcpSendCompleted(this, args);

            return true;
        }

        /// <inheritdoc/>
        public override bool SendMessageUnreliable(MessageBuffer message)
        {
            if (!CanSend)
                return false;

            networkListener.SendUdpBuffer(RemoteUdpEndPoint, message, UdpSendCompleted);

            return true;
        }

        /// <summary>
        ///     Disconnects this client from the remote host.
        /// </summary>
        /// <returns>Whether the disconnect was successful.</returns>
        public override bool Disconnect()
        {
            if (!CanSend && !IsListening)
                return false;

            try
            {
                tcpSocket.Shutdown(SocketShutdown.Both);
            }
            catch (SocketException)
            {
                //Ignore exception as socket is already shutdown
            }

            networkListener.UnregisterUdpConnection(this);

            CanSend = false;
            IsListening = false;

            return true;
        }

        /// <summary>
        ///     Called when the 4 byte length header is received by TCP
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TcpHeaderReceiveCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred != 4 || e.SocketError != SocketError.Success)
            {
                HandleDisconnection(e.SocketError);
                
                e.Completed -= TcpHeaderReceiveCompleted;
                ObjectCache.ReturnSocketAsyncEventArgs(e);

                return;
            }

            if (e.Offset + e.BytesTransferred < e.Buffer.Length)
            {
                e.SetBuffer(e.Buffer, e.Offset + e.BytesTransferred, e.Buffer.Length - e.Offset - e.BytesTransferred);
                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpHeaderReceiveCompleted(this, e);
            }
            else
            {
                int length = BigEndianHelper.ReadInt32(e.Buffer, 0);

                //TODO 2 catch length < 0 errors here and strike!

                MessageBuffer buffer = MessageBuffer.Create(length);
                buffer.Count = length;

                e.SetBuffer(buffer.Buffer, 0, length);
                e.UserToken = buffer;
                e.Completed -= TcpHeaderReceiveCompleted;
                e.Completed += TcpBodyReceiveCompleted;

                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpBodyReceiveCompleted(this, e);
            }
        }

        /// <summary>
        ///     Called when the body of a TCP message is received.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TcpBodyReceiveCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred == 0 || e.SocketError != SocketError.Success)
            {
                HandleDisconnection(e.SocketError);
                
                e.Completed -= TcpBodyReceiveCompleted;
                ObjectCache.ReturnSocketAsyncEventArgs(e);

                return;
            }

            //Check we've received all the message
            if (e.Offset + e.BytesTransferred < e.Buffer.Length)
            {
                e.SetBuffer(e.Buffer, e.Offset + e.BytesTransferred, e.Buffer.Length - e.Offset - e.BytesTransferred);
                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpBodyReceiveCompleted(this, e);
            }
            else
            {
                byte[] data = e.Buffer;

                e.SetBuffer(new byte[4], 0, 4);
                e.Completed -= TcpBodyReceiveCompleted;
                e.Completed += TcpHeaderReceiveCompleted;

                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpHeaderReceiveCompleted(this, e);

                MessageBuffer buffer = (MessageBuffer)e.UserToken;

                HandleMessageReceived(buffer, SendMode.Reliable);

                //Cleanup
                buffer.Dispose();
            }
        }

        /// <summary>
        ///     Handles a UDP message sent to the listener.
        /// </summary>
        internal void HandleUdpMessage(MessageBuffer buffer)
        {
            HandleMessageReceived(buffer, SendMode.Unreliable);
        }

        /// <summary>
        ///     Called when a TCP send has completed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TcpSendCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.SocketError != SocketError.Success)
                UnregisterAndDisconnect(e.SocketError);
            
            e.Completed -= TcpSendCompleted;

            //Always dispose buffer when completed!
            ((MessageBuffer)e.UserToken).Dispose();

            ObjectCache.ReturnSocketAsyncEventArgs(e);
        }

        /// <summary>
        ///     Called when a UDP send has completed.
        /// </summary>
        /// <param name="e">The socket error that was returned.</param>
        private void UdpSendCompleted(SocketError e)
        {
            if (e != SocketError.Success)
                UnregisterAndDisconnect(e);
        }

        /// <summary>
        ///     Called when a socket error has occured.
        /// </summary>
        /// <param name="error"></param>
        private void UnregisterAndDisconnect(SocketError error)
        {
            if (CanSend || IsListening)
            {
                networkListener.UnregisterUdpConnection(this);

                CanSend = false;
                IsListening = false;

                HandleDisconnection(error);
            }
        }
        
        /// <inheritdoc/>
        public override IPEndPoint GetRemoteEndPoint(string name)
        {
            if (name.ToLower() == "tcp")
                return RemoteTcpEndPoint;
            else if (name.ToLower() == "udp")
                return RemoteUdpEndPoint;
            else
                throw new ArgumentException("Endpoint name must either be TCP or UDP");
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected override void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    if (IsListening || CanSend)
                        Disconnect();

                    tcpSocket.Close();
                }

                disposedValue = true;
            }
        }
        
        #endregion
    }
}