﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace DarkRift.Server.Plugins.Listeners.Bichannel
{
    sealed class CompatibilityBichannelListener : BichannelListenerBase
    {
        public override Version Version => new Version(1, 0, 0);
        
        public CompatibilityBichannelListener(NetworkListenerLoadData listenerLoadData) : base(listenerLoadData)
        {
        }

        public override void StartListening()
        {
            BindSockets();

            WriteEvent("Starting compatibility listener.", LogType.Trace);

            TcpListener.BeginAccept(TcpAcceptCompleted, null);

            EndPoint remoteEndPoint = new IPEndPoint(IPVersion == IPVersion.IPv6 ? IPAddress.IPv6Any : IPAddress.Any, 0);
            byte[] buffer = new byte[ushort.MaxValue];
            udpListener.BeginReceiveFrom(buffer, 0, ushort.MaxValue, SocketFlags.None, ref remoteEndPoint, UdpMessageReceived, buffer);

            WriteEvent($"Server mounted, listening on port {Port}.", LogType.Info);
        }

        /// <summary>
        ///     Called when a new client has been accepted through the fallback accept.
        /// </summary>
        /// <param name="result">The result of the accept.</param>
        void TcpAcceptCompleted(IAsyncResult result)
        {
            Socket socket;
            try
            {
                socket = TcpListener.EndAccept(result);
            }
            catch
            {
                return;
            }

            try
            {
                HandleTcpConnection(socket);
            }
            finally
            {
                TcpListener.BeginAccept(TcpAcceptCompleted, null);
            }
        }

        /// <summary>
        ///     Called when a UDP message is received on the fallback system.
        /// </summary>
        /// <param name="result">The result of the operation.</param>
        void UdpMessageReceived(IAsyncResult result)
        {
            EndPoint remoteEndPoint = new IPEndPoint(IPVersion == IPVersion.IPv6 ? IPAddress.IPv6Any : IPAddress.Any, 0);
            int bytesReceived;
            try
            {
                bytesReceived = udpListener.EndReceiveFrom(result, ref remoteEndPoint);
            }
            catch (SocketException)
            {
                udpListener.BeginReceiveFrom((byte[])result.AsyncState, 0, ushort.MaxValue, SocketFlags.None, ref remoteEndPoint, UdpMessageReceived, (byte[])result.AsyncState);
                return;
            }

            //Copy over buffer and remote endpoint
            using (MessageBuffer buffer = MessageBuffer.Create(bytesReceived))
            {
                Buffer.BlockCopy((byte[])result.AsyncState, 0, buffer.Buffer, buffer.Offset, bytesReceived);
                buffer.Count = bytesReceived;

                //Start listening again
                udpListener.BeginReceiveFrom((byte[])result.AsyncState, 0, ushort.MaxValue, SocketFlags.None, ref remoteEndPoint, UdpMessageReceived, (byte[])result.AsyncState);

                //Handle message or new connection
                BichannelServerConnection connection;
                bool exists;
                lock (UdpConnections)
                    exists = UdpConnections.TryGetValue(remoteEndPoint, out connection);

                if (exists)
                    connection.HandleUdpMessage(buffer);
                else
                    HandleUdpConnection(buffer, remoteEndPoint);
            }
        }
        
        class UdpSendOperation
        {
            public Action<SocketError> callback;
            public MessageBuffer message;
        }

        internal override void SendUdpBuffer(EndPoint remoteEndPoint, MessageBuffer message, Action<SocketError> completed)
        {
            udpListener.BeginSendTo(message.Buffer, message.Offset, message.Count, SocketFlags.None, remoteEndPoint, UdpSendCompleted, new UdpSendOperation { callback = completed, message = message });
        }
        
        void UdpSendCompleted(IAsyncResult result)
        {
            UdpSendOperation operation = result.AsyncState as UdpSendOperation;

            int bytesSent;
            try
            {
                bytesSent = udpListener.EndSendTo(result);
            }
            catch (SocketException e)
            {
                operation.message.Dispose();

                operation.callback(e.SocketErrorCode);
                return;
            }

            operation.message.Dispose();

            operation.callback(SocketError.Success);
        }
    }
}
