﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace DarkRift.Server.Plugins.Listeners.Bichannel
{
    abstract class BichannelListenerBase : NetworkListener
    {
        /// <summary>
        ///     The TCP listening socket.
        /// </summary>
        protected Socket TcpListener { get; }

        /// <summary>
        ///     The UDP listening socket.
        /// </summary>
        protected Socket udpListener { get; }

        /// <summary>
        ///     The IP address to listen on.
        /// </summary>
        public IPAddress Address { get; }

        /// <summary>
        ///     The port to listen on.
        /// </summary>
        public int Port { get; }

        /// <summary>
        ///     The IP version we're listening on.
        /// </summary>
        public IPVersion IPVersion { get; }

        /// <summary>
        ///     Whether Nagle's algorithm should be disabled.
        /// </summary>
        public bool NoDelay
        {
            get => TcpListener.NoDelay;
            set
            {
                TcpListener.NoDelay = value;
            }
        }

        /// <summary>
        ///     Dictionary of TCP connections awaiting their UDP counterpart.
        /// </summary>
        protected Dictionary<long, PendingConnection> PendingTcpSockets { get; } = new Dictionary<long, PendingConnection>();

        /// <summary>
        ///     Represents a connection to the server awaiting the UDP channel to connect.
        /// </summary>
        protected struct PendingConnection
        {
            /// <summary>
            ///     The TCP endpoint pending.
            /// </summary>
            public EndPoint RemoteEndPoint { get; set; }

            /// <summary>
            ///     The TCP socket connected.
            /// </summary>
            public Socket TcpSocket { get; set; }

            /// <summary>
            ///     The timer for timing out the connection request.
            /// </summary>
            public System.Threading.Timer Timer { get; set; }
        }

        /// <summary>
        ///     The UDP connections to the server.
        /// </summary>
        protected Dictionary<EndPoint, BichannelServerConnection> UdpConnections { get; } = new Dictionary<EndPoint, BichannelServerConnection>();

        public BichannelListenerBase(NetworkListenerLoadData listenerLoadData)
            : base(listenerLoadData)
        {
            this.Address = IPAddress.Parse(listenerLoadData.Settings["address"]);
            this.Port = int.Parse(listenerLoadData.Settings["port"]);
            this.IPVersion = listenerLoadData.Settings["ipVersion"].ToLower() == "ipv6" ? IPVersion.IPv6 : IPVersion.IPv4;

            AddressFamily addressFamily = IPVersion == IPVersion.IPv6 ? AddressFamily.InterNetworkV6 : AddressFamily.InterNetwork;

            TcpListener = new Socket(addressFamily, SocketType.Stream, ProtocolType.Tcp);
            udpListener = new Socket(addressFamily, SocketType.Dgram, ProtocolType.Udp);

            this.NoDelay = listenerLoadData.Settings["noDelay"]?.ToLower() == "true";
        }

        /// <summary>
        ///     Binds the sockets to their ports.
        /// </summary>
        protected void BindSockets()
        {
            TcpListener.Bind(new IPEndPoint(Address, Port));
            TcpListener.Listen(100);

            udpListener.Bind(new IPEndPoint(Address, Port));
        }

        /// <summary>
        ///     Handles new TCP connections from main or fallback methods.
        /// </summary>
        /// <param name="acceptSocket">The socket accepted.</param>
        protected void HandleTcpConnection(Socket acceptSocket)
        {
            WriteEvent("Accepted TCP connection from " + acceptSocket.RemoteEndPoint + ".", LogType.Trace);

            long token;
            lock (PendingTcpSockets)
            {
                //Generate random authentication token
                Random r = new Random();
                do
                    token = ((long)r.Next() << 32) | (long)r.Next();
                while (PendingTcpSockets.ContainsKey(token));

                //Create pending connection object
                PendingConnection pendingConnection = new PendingConnection
                {
                    TcpSocket = acceptSocket,
                    Timer = new System.Threading.Timer(ConnectionTimeoutHandler, token, 5000, Timeout.Infinite)
                };

                //Store token
                PendingTcpSockets[token] = pendingConnection;
            }

            acceptSocket.NoDelay = NoDelay;

            try
            {
                //Send token via TCP
                byte[] buffer = new byte[9];                    //Version, Token * 8
                BigEndianHelper.WriteBytes(buffer, 1, token);
                acceptSocket.Send(buffer);
            }
            catch (SocketException e)
            {
                //Failed to send auth token, cleanup
                EndPoint remoteEndPoint = CancelPendingTcpConnection(token);

                if (remoteEndPoint != null)
                    Server.InternalLogManager.WriteEvent(nameof(NetworkListener), "A SocketException occurred whilst sending the auth token to " + remoteEndPoint + ". It is likely the client disconnected before the server was able.", LogType.Trace, e);
            }
        }

        /// <summary>
        ///     Called when a connection times out due to lack the of a UDP connection.
        /// </summary>
        /// <param name="state">The token given to the connection.</param>
        void ConnectionTimeoutHandler(object state)
        {
            EndPoint remoteEndPoint = CancelPendingTcpConnection((long)state);

            //Check found (should always be but will crash server otherwise)
            if (remoteEndPoint != null)
                Server.InternalLogManager.WriteEvent(nameof(NetworkListener), "Connection attempt from " + remoteEndPoint + " timed out.", LogType.Trace);
        }

        /// <summary>
        ///     Cancels a pending TCP socket and timers.
        /// </summary>
        /// <param name="token">The identification token for the connection.</param>
        /// <returns>The endpoint associated with the connection.</returns>
        EndPoint CancelPendingTcpConnection(long token)
        {
            lock (PendingTcpSockets)
            {
                PendingConnection connection = PendingTcpSockets[token];
                connection.Timer.Dispose();
                connection.TcpSocket.Close();
                PendingTcpSockets.Remove(token);

                return connection.RemoteEndPoint;
            }
        }


        /// <summary>
        ///     Handles a new connection to the UDP listener.
        /// </summary>
        /// <param name="buffer">The buffer sent as an entry.</param>
        /// <param name="remoteEndPoint">The originating endpoint.</param>
        protected void HandleUdpConnection(MessageBuffer buffer, EndPoint remoteEndPoint)
        {
            //Check length
            if (buffer.Count != 9)
                return;

            //Decode token
            long token = BigEndianHelper.ReadInt64(buffer.Buffer, buffer.Offset + 1);

            //Lookup TCP socket
            Socket tcpSocket;
            lock (PendingTcpSockets)
            {
                //Get connection
                PendingConnection pendingConnection;
                if (!PendingTcpSockets.TryGetValue(token, out pendingConnection))
                {
                    tcpSocket = null;
                }
                else
                {
                    //Dispose timer and remove from pending list
                    pendingConnection.Timer.Dispose();
                    PendingTcpSockets.Remove(token);

                    tcpSocket = pendingConnection.TcpSocket;
                }
            }

            if (tcpSocket != null)
            {
                WriteEvent("Accepted UDP connection from " + remoteEndPoint + ".", LogType.Trace);

                //Create connection object
                BichannelServerConnection connection = new BichannelServerConnection(tcpSocket, this, (IPEndPoint)remoteEndPoint, token);

                //Send message back to client to say hi
                using (MessageBuffer hiBuffer = MessageBuffer.Create(1))
                    connection.SendMessageUnreliable(hiBuffer);        //Version

                //Inform everyone
                RegisterConnection(connection);
            }
            else
            {
                WriteEvent("UDP connection from " + remoteEndPoint + " had no associated TCP connection.", LogType.Trace);
                return;
            }
        }

        /// <summary>
        ///     Subscribes a connection to receive messages.
        /// </summary>
        /// <param name="connection">The connection to subscribe.</param>
        internal void RegisterUdpConnection(BichannelServerConnection connection)
        {
            //Register for UDP messages
            lock (UdpConnections)
                UdpConnections.Add(connection.RemoteUdpEndPoint, connection);
        }

        /// <summary>
        ///     Unsubscribes a connection from receiveing messages.
        /// </summary>
        /// <param name="connection">The connection to subscribe.</param>
        internal void UnregisterUdpConnection(BichannelServerConnection connection)
        {
            //Register for UDP messages
            lock (UdpConnections)
                UdpConnections.Remove(connection.RemoteUdpEndPoint);
        }
        
        /// <summary>
        ///     Sends a buffer to the given endpoint using the UDP socket.
        /// </summary>
        /// <param name="remoteEndPoint">The end point to send to.</param>
        /// <param name="message">The message to send.</param>
        /// <param name="completed">The function to invoke once the send is completed.</param>
        internal abstract void SendUdpBuffer(EndPoint remoteEndPoint, MessageBuffer message, Action<SocketError> completed);

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected override void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    TcpListener.Close();
                    udpListener.Close();
                }

                disposedValue = true;
            }
        }

        #endregion
    }
}
