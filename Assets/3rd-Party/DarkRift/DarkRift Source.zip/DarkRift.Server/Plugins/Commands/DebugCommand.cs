﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    class DebugCommand : Plugin
    {
        public override bool ThreadSafe => true;

        public override Version Version => new Version(1, 0, 0);

        public override Command[] Commands => new Command[]
        {
            new Command("set-property", "Sets a property in the server.", "set-property -<property-name>=<value>|-<property-name>...", SetProperty)
        };

        internal override bool Hidden => true;

        public DebugCommand(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {
        }

        void SetProperty(object sender, CommandEventArgs e)
        {
            foreach (string property in e.Flags.Keys)
            {
                switch (property)
                {
                    case "events-from-dispatcher":
                        if (e.Flags[property] != null)
                            throw new CommandSyntaxException("Cannot set events-from-dispatcher to anything else but true.");

                        ThreadHelper.SetEventsFromDispatcher();
                        break;

                    default:
                        throw new CommandSyntaxException("Unknown property.");
                }

                if (e.Flags[property] != null)
                    WriteEvent(property + " set to " + e.Flags[property] + ".", LogType.Info);
                else
                    WriteEvent(property + " set.", LogType.Info);
            }
        }
    }
}
