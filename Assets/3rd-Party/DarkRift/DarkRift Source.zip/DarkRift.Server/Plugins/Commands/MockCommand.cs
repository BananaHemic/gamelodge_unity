﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    /// <summary>
    ///     Helper plugin for pretending to receive messages using commands.
    /// </summary>
    class MockCommand : Plugin
    {
        public override bool ThreadSafe => true;

        public override Version Version => new Version(1, 0, 0);

        public override Command[] Commands => new Command[]
        {
            new Command("mock", "Mocks message receiving for testing plugins.", "mock <client> <sendMode> <tag> <data> <data> <data> ...", CommandHandler)
        };

        internal override bool Hidden => true;

        public MockCommand(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {
        }

        void CommandHandler(object sender, CommandEventArgs e)
        {
            if (e.Arguments.Length < 3)
                throw new CommandSyntaxException();
            
            using (DarkRiftWriter writer = DarkRiftWriter.Create())
            {
                SendMode sendMode;
                ushort clientID;
                ushort tag;

                try
                {
                    clientID = ushort.Parse(e.Arguments[0]);

                    switch (e.Arguments[1].ToLower())
                    {
                        case "unreliable":
                        case "u":
                            sendMode = SendMode.Unreliable;
                            break;

                        case "reliable":
                        case "r":
                            sendMode = SendMode.Reliable;
                            break;

                        default:
                            throw new CommandSyntaxException();
                    }

                    tag = ushort.Parse(e.Arguments[2]);

                    IEnumerable<byte> bytes =
                        e.Arguments
                            .Skip(3)
                            .Select((a) => byte.Parse(a));

                    foreach (byte b in bytes)
                        writer.Write(b);
                }
                catch (FormatException)
                {
                    throw new CommandSyntaxException();
                }

                using (Message message = Message.Create(tag, writer))
                {
                    try
                    {
                        ((Client)ClientManager[clientID]).HandleIncomingMessage(message, sendMode);
                    }
                    catch (KeyNotFoundException)
                    {
                        Server.InternalLogManager.WriteEvent(nameof(MessageCommand), "No client with id " + clientID, LogType.Error);
                    }
                }
            }
        }
    }
}
