﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    /// <summary>
    ///     Packet sniffer plugin.
    /// </summary>
    class Sniffer : Plugin
    {
        public override Version Version => new Version(1, 0, 0);

        public override Command[] Commands
        {
            get
            {
                return new Command[]
                {
                    new Command("sniffer", "Configures the message sniffer.", "sniffer add|remove (-a|-all) (-t|-tag=<tag>) (-id=<id>) (-ip=<ip>)\nsniffer clear\nsniffer list", SniffCommandHandler)
                };
            }
        }

        public override bool ThreadSafe => true;

        internal override bool Hidden => true;

        /// <summary>
        ///     The rules we are following
        /// </summary>
        HashSet<RuleGroup> rules = new HashSet<RuleGroup>();

        public Sniffer(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {
            
        }

        private void ClientManager_ClientConnected(object sender, ClientConnectedEventArgs e)
        {
            e.Client.MessageReceived += Client_MessageReceived;
        }

        private void Client_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            using (Message message = e.GetMessage())
            {
                lock (rules)
                {
                    foreach (RuleGroup group in rules)
                    {
                        if (group.Accepts(message, (Client)sender))
                        {
                            StringBuilder builder = new StringBuilder();
                            builder.Append('[');
                            builder.Append(e.Client.ID);
                            builder.Append("] ");
                            builder.Append(message);

                            Server.InternalLogManager.WriteEvent(Name, builder.ToString(), LogType.Info);
                            return;
                        }
                    }
                }
            }
        }

        private void SniffCommandHandler(object sender, CommandEventArgs e)
        {
            //Check args length
            if (e.Arguments.Length != 1)
                throw new CommandSyntaxException();

            RuleGroup group = BuildRuleGroup(e.Flags);

            if (group == null)
                throw new CommandSyntaxException();

            lock (rules)
            {
                switch (e.Arguments[0])
                {
                    //Add rule groups
                    case "add":
                        if (group.Count == 0)
                            throw new CommandSyntaxException();

                        bool added = rules.Add(group);

                        if (added)
                        {
                            //Subscribe to events if we're the first rule
                            if (rules.Count == 1)
                            {
                                ClientManager.ClientConnected += ClientManager_ClientConnected;

                                foreach (Client client in ClientManager.GetAllClients())
                                    client.MessageReceived += Client_MessageReceived;
                            }

                            WriteEvent("Now sniffing " + group.ToString(), LogType.Info);
                        }
                        else
                        {
                            WriteEvent("Already sniffing " + group.ToString(), LogType.Info);
                        }

                        break;

                    //Remove rule groups
                    case "remove":
                        if (group.Count == 0)
                            throw new CommandSyntaxException();

                        bool removed = rules.Remove(group);

                        if (removed)
                        {
                            //Unsubscribe to events if there's no more rules
                            if (rules.Count == 0)
                            {
                                ClientManager.ClientConnected -= ClientManager_ClientConnected;

                                foreach (Client client in ClientManager.GetAllClients())
                                    client.MessageReceived -= Client_MessageReceived;
                            }

                            WriteEvent("No longer sniffing " + group.ToString(), LogType.Info);
                        }
                        else
                        {
                            WriteEvent("Not sniffing " + group.ToString(), LogType.Info);
                        }

                        break;

                    //Clear all rule groups
                    case "clear":
                        if (group.Count != 0)
                            throw new CommandSyntaxException();

                        rules.Clear();

                        ClientManager.ClientConnected -= ClientManager_ClientConnected;

                        foreach (Client client in ClientManager.GetAllClients())
                            client.MessageReceived -= Client_MessageReceived;

                        WriteEvent("All sniffing rules cleared.", LogType.Info);

                        break;

                    //List sniffing rules
                    case "list":
                        StringBuilder builder = new StringBuilder();
                        builder.Append("Found " + rules.Count + " rules defined.");
                        int i = 1;
                        foreach (RuleGroup rule in rules)
                            builder.Append("\n" + i++ + "\t" + rule.ToString());

                        WriteEvent(builder.ToString(), LogType.Info);

                        break;

                    //Complain
                    default:
                        throw new CommandSyntaxException();
                }
            }
        }

        private RuleGroup BuildRuleGroup(NameValueCollection flags)
        {
            RuleGroup group = new RuleGroup();

            //Load all rules
            if (flags.AllKeys.Contains("a") || flags.AllKeys.Contains("all"))
            {
                group.Add(new ALLTHERULES());

                return group;
            }

            //Load tag rules
            try
            {
                if (flags.AllKeys.Contains("t"))
                    group.Add(new TagRule(ushort.Parse(flags["t"])));
                else if (flags.AllKeys.Contains("tag"))
                    group.Add(new TagRule(ushort.Parse(flags["tag"])));
            }
            catch (FormatException)
            {
                throw new CommandSyntaxException();
            }
            catch (OverflowException)
            {
                throw new CommandSyntaxException();
            }

            //Load ID rules
            try
            {
                if (flags.AllKeys.Contains("id"))
                    group.Add(new IDRule(uint.Parse(flags["id"])));
            }
            catch (FormatException)
            {
                throw new CommandSyntaxException();
            }
            catch (OverflowException)
            {
                throw new CommandSyntaxException();
            }

            //Load IP rules
            try
            {
                if (flags.AllKeys.Contains("ip"))
                    group.Add(new IPRule(IPAddress.Parse(flags["ip"])));
            }
            catch (FormatException)
            {
                throw new CommandSyntaxException();
            }

            return group;
        }
    }
}
