﻿using System.Collections.Generic;
using System.Linq;
using System.Net;

namespace DarkRift.Server.Plugins.Commands
{
    internal class MockedNetworkServerConnection : NetworkServerConnection
    {
        public override ConnectionState ConnectionState => ConnectionState.Connected;

        public override IEnumerable<IPEndPoint> RemoteEndPoints { get; }

        /// <summary>
        ///     The client command plugin that owns us.
        /// </summary>
        ClientCommand clientCommand;

        public MockedNetworkServerConnection(ClientCommand clientCommand, IPAddress ip, ushort port)
        {
            this.clientCommand = clientCommand;
            this.RemoteEndPoints = new IPEndPoint[] { new IPEndPoint(ip, port) };
        }

        public override bool Disconnect()
        {
            clientCommand.HandleDisconnection(this);
            return true;
        }

        public override IPEndPoint GetRemoteEndPoint(string name)
        {
            return RemoteEndPoints.First();
        }

        public override bool SendMessageReliable(MessageBuffer message)
        {
            clientCommand.HandleReliableSend(this, message);
            return true;
        }

        public override bool SendMessageUnreliable(MessageBuffer message)
        {
            clientCommand.HandleUnreliableSend(this, message);
            return true;
        }

        public override void StartListening()
        {
            
        }
    }
}