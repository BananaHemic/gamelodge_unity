﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    /// <summary>
    ///     Help command!
    /// </summary>
    sealed class HelpCommand : Plugin
    {
        public override Version Version => new Version(1, 0, 0);

        public override bool ThreadSafe => true;

        internal override bool Hidden => true;

        public override Command[] Commands
        {
            get
            {
                return new Command[]
                {
                    new Command("help", "Retrieves the documentation for a specified command.", "help <command>", Help)
                };
            }
        }

        public HelpCommand(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {
        }

        private void Help(object sender, CommandEventArgs e)
        {
            if (e.RawArguments.Length != 1)
                throw new CommandSyntaxException();

            Command command;
            try
            {
                command = Server.CommandEngine.FindCommand(e.RawArguments[0]);
            }
            catch (Exception exception)
            {
                Server.InternalLogManager.WriteEvent(Name, exception.Message, LogType.Error);

                return;
            }

            Server.InternalLogManager.WriteEvent(
                Name,
                $"Command: \"{command.Name}\"\n\nUsage:\n{command.Usage}\n\nDescription:\n{command.Description}",
                LogType.Info
            );
        }
    }
}
