﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    /// <summary>
    ///     Plugin management plugin.
    /// </summary>
    class PluginController : Plugin
    {
        public override Version Version => new Version(1, 0, 0);

        public override Command[] Commands
        {
            get
            {
                return new Command[]
                {
                    new Command("plugins", "Allows management of installed plugins.", "plugins uninstall <plugin-name>\nplugins loaded (-h)\n\tAdding option -h will include hidden plugins.\nplugins installed", CommandHandler)
                };
            }
        }

        public override bool ThreadSafe => true;

        internal override bool Hidden => true;
        
        public PluginController(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {
        }

        private void CommandHandler(object sender, CommandEventArgs e)
        {
            if (e.Arguments.Length < 1)
                throw new CommandSyntaxException();

            if (e.Arguments[0] == "uninstall")
                Uninstall(e);
            else if (e.Arguments[0] == "loaded")
                ListLoaded(e);
            else if (e.Arguments[0] == "installed")
                ListInstalled(e);
            else
                WriteEvent($"Usage: {e.Command.Usage}", LogType.Error);
        }

        void Uninstall(CommandEventArgs e)
        {
            if (e.Arguments.Length != 2)
                throw new CommandSyntaxException();

            try
            {
                Server.InternalPluginManager.Uninstall(e.Arguments[1]);

                WriteEvent("Uninstall successful", LogType.Info);
            }
            catch (InvalidOperationException ex)
            {
                WriteEvent(ex.Message, LogType.Error);
            }
            catch (KeyNotFoundException)
            {
                WriteEvent("No plugins by that name could be found.", LogType.Error);
            }
        }

        void ListLoaded(CommandEventArgs e)
        {
            if (e.Arguments.Length != 1)
                throw new CommandSyntaxException();

            Plugin[] loaded;
            if (e.HasFlag("h"))
                loaded = Server.InternalPluginManager.ActuallyGetAllPlugins();
            else
                loaded = Server.InternalPluginManager.GetAllPlugins();

            StringBuilder sb = new StringBuilder();
            sb.Append("Found ");
            sb.Append(loaded.Length);
            sb.AppendLine(" plugins loaded.");
            for (int i = 0; i < loaded.Length; i++)
            {
                sb.Append((i+1).ToString().PadRight(4));
                sb.Append(loaded[i].Name.PadRight(24));
                sb.AppendLine(loaded[i].Hidden ? "(Hidden)" : "");
            }

            WriteEvent(sb.ToString(), LogType.Info);
        }

        void ListInstalled(CommandEventArgs e)
        {
            if (e.Arguments.Length != 1)
                throw new CommandSyntaxException();

            StringBuilder sb = new StringBuilder();
                        
            int i = 0;
            foreach (PluginRecord plugin in Server.DataManager.ReadAllPluginRecords())
            {
                sb.Append((++i).ToString().PadRight(4));
                sb.Append(plugin.Name.PadRight(24));
                sb.Append(" ");
                sb.Append("V");
                sb.AppendLine(plugin.Version.ToString());
            }

            sb.Insert(0, "Found " + i + " plugins installed.\n");

            WriteEvent(sb.ToString(), LogType.Info);
        }
    }
}
