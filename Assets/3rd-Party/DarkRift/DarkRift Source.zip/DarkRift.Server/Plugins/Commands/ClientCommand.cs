﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace DarkRift.Server.Plugins.Commands
{
    class ClientCommand : Plugin
    {
        public override bool ThreadSafe => true;

        public override Version Version => new Version(1, 0, 0);

        public override Command[] Commands => new Command[]
        {
            new Command("client", "Creates mock clients for testing.", "client add (-ip=<ip>) (-port|p=<port>)\nclient remove <id>", ClientCommandHandler)
        };

        internal override bool Hidden => true;

        /// <summary>
        ///     The current mock clients.
        /// </summary>
        Dictionary<int, MockedNetworkServerConnection> connections = new Dictionary<int, MockedNetworkServerConnection>();

        public ClientCommand(PluginLoadData pluginLoadData) : base(pluginLoadData)
        {

        }
        
        private void ClientCommandHandler(object sender, CommandEventArgs e)
        {
            if (e.Arguments.Length < 1)
                throw new CommandSyntaxException();

            if (e.Arguments[0].ToLower() == "new")
            {
                if (e.Arguments.Length != 1)
                    throw new CommandSyntaxException();

                IPAddress ip;
                if (e.Flags["ip"] != null)
                {
                    if (!IPAddress.TryParse(e.Flags["ip"], out ip))
                        throw new CommandSyntaxException("Could not parse the IP address of the client to create.");
                }
                else
                {
                    ip = IPAddress.Loopback;
                }

                ushort port;
                if (e.Flags["port"] != null)
                {
                    if (!ushort.TryParse(e.Flags["port"], out port))
                        throw new CommandSyntaxException("Could not parse the port of the client to create.");
                }
                else if (e.Flags["p"] != null)
                {
                    if (!ushort.TryParse(e.Flags["p"], out port))
                        throw new CommandSyntaxException("Could not parse the port of the client to create.");
                }
                else
                {
                    port = 0;
                }

                MockedNetworkServerConnection connection = new MockedNetworkServerConnection(this, ip, port);
                Server.InternalClientManager.HandleNewConnection(connection);
                connections.Add(connection.Client.ID, connection);
            }
            else if (e.Arguments[0].ToLower() == "remove")
            {
                if (e.Arguments.Length != 2)
                    throw new CommandSyntaxException();

                if (!int.TryParse(e.Arguments[1], out int id))
                    throw new CommandSyntaxException("Could not parse the ID of the client to disconnect.");

                if (!connections.TryGetValue(id, out MockedNetworkServerConnection connection))
                    throw new CommandSyntaxException("You can only disconnect clients previously created with the client command.");

                Server.InternalClientManager.HandleDisconnection(connection.Client, true, SocketError.Success, null);
            }
        }

        /// <summary>
        ///     Handles a mock connection being disconnected.
        /// </summary>
        internal void HandleDisconnection(MockedNetworkServerConnection connection)
        {
            connections.Remove(connection.Client.ID);
        }

        /// <summary>
        ///     Handles sending to a mock connection.
        /// </summary>
        internal void HandleUnreliableSend(MockedNetworkServerConnection connection, MessageBuffer message)
        {
            WriteEvent("Unreliable message sent to " + connection.Client.ID + ".", LogType.Info);
        }

        /// <summary>
        ///     Handles sending to a mock connection.
        /// </summary>
        internal void HandleReliableSend(MockedNetworkServerConnection connection, MessageBuffer message)
        {
            WriteEvent("Reliable message sent to " + connection.Client.ID + ".", LogType.Info);
        }
    }
}
