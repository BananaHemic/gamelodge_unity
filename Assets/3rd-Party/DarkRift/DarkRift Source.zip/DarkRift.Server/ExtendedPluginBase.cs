﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Base class for all <see cref="DataConnector">Data Connectors</see> and <see cref="Plugin">Plugins</see>.
    /// </summary>
    public abstract class ExtendedPluginBase : PluginBase
    {
        /// <summary>
        ///     Is this plugin able to handle multithreaded events?
        /// </summary>
        /// <remarks>
        ///     Enabling this option allows DarkRift to send messages to your plugin from multiple threads simultaneously, 
        ///     greatly increasing performance. Do not enable this unless you are confident that you understand 
        ///     multithreading else you will find yourself with a variety of unfriendly problems to fix!
        /// </remarks>
        public abstract bool ThreadSafe { get; }

        /// <summary>
        ///     The commands the plugin has.
        /// </summary>
        /// <remarks>
        ///     This is an array of commands that can be executed by this plugin and will be searched through when the 
        ///     command is executed. Changes to this array will be reflected instantly by the command system.
        /// </remarks>
        public virtual Command[] Commands => new Command[0];

        /// <summary>
        ///     The handler for writing events.
        /// </summary>
        WriteEventHandler writeEventHandler;

        public ExtendedPluginBase(ExtendedPluginBaseLoadData pluginLoadData)
            : base(pluginLoadData)
        {
            writeEventHandler = pluginLoadData.WriteEventHandler;
        }

        /// <summary>
        ///     Writes an event to the server's logs.
        /// </summary>
        /// <param name="message">The message to write.</param>
        /// <param name="logType">The type of message to write.</param>
        /// <param name="exception">The exception that occurred (if there was one).</param>
        protected void WriteEvent(string message, LogType logType, Exception exception = null)
        {
            writeEventHandler(message, logType, exception);
        }

        /// <summary>
        ///     Method that will be called when the server and all plugins have loaded.
        /// </summary>
        /// <param name="args">The details of the load.</param>
        /// <remarks>Pro only.</remarks>
#if PRO
        protected
#endif
        internal virtual void Loaded(LoadedEventArgs args)
        { }

        /// <summary>
        ///     Method that will be called when the plugin is installed.
        /// </summary>
        /// <param name="args">The details of the installation.</param>
        /// <remarks>Pro only.</remarks>
#if PRO
        protected
#endif
        internal virtual void Install(InstallEventArgs args)
        { }

        /// <summary>
        ///     Method that will be called when the plugin is upgraded.
        /// </summary>
        /// <param name="args">The details of the upgrade.</param>
        /// <remarks>Pro only.</remarks>
#if PRO
        protected
#endif
        internal virtual void Upgrade(UpgradeEventArgs args)
        { }
    }
}
