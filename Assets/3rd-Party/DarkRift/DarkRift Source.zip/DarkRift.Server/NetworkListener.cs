﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Base class for all plugins providing network functionality.
    /// </summary>
    public abstract class NetworkListener : PluginBase
    {
        public NetworkListener(NetworkListenerLoadData pluginLoadData) : base(pluginLoadData)
        {
        }
        
        /// <summary>
        ///     Writes an event to the server's logs.
        /// </summary>
        /// <param name="message">The message to write.</param>
        /// <param name="logType">The type of message to write.</param>
        /// <param name="exception">The exception that occurred (if there was one).</param>
        protected void WriteEvent(string message, LogType logType, Exception exception = null)
        {
            Server.InternalLogManager.WriteEvent(Name, message, logType, exception);
        }

        /// <summary>
        ///     Registers a new connection to the server.
        /// </summary>
        /// <param name="connection">The new connection.</param>
        protected void RegisterConnection(NetworkServerConnection connection)
        {
            Server.InternalClientManager.HandleNewConnection(connection);
        }

        /// <summary>
        ///     Starts the listener listening on the network.
        /// </summary>
        public abstract void StartListening();
    }
}
