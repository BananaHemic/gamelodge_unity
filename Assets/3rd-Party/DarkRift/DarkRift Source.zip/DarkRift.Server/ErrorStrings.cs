﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Collection of DarkRift error strings.
    /// </summary>
    static class ErrorStrings
    {
        //Plugins exception strings

        internal static readonly string DISCONNECTED_PLUGIN_EXCEPTION           = "An plugin encountered an error whilst handling the Disconnected event. (See logs for exception)";
        internal static readonly string MESSAGERECEIVIED_PLUGIN_EXCEPTION       = "An plugin encountered an error whilst handling the MessageReceived event.";
        internal static readonly string STRIKEOCCURED_PLUGIN_EXCEPTION          = "An plugin encountered an error whilst handling the StrikeOccured event. The strike will stand. (See logs for exception)";
        internal static readonly string CLIENTCONNECTED_PLUGIN_EXCEPTION        = "An plugin encountered an error whilst handling the ClientConnected event. The client will still be connected. (See logs for exception)";
        internal static readonly string CLIENTDISCONNECTED_PLUGIN_EXCEPTION     = "An plugin encountered an error whilst handling the ClientDisconnected event. (See logs for exception)";
        internal static readonly string COMMAND_PLUGIN_EXCEPTION                = "An plugin encountered an error whilst handling the command \"{0}\". (See logs for exception)";
        
        //Command strings

        internal static readonly string NO_PLUGINS_WITH_COMMAND                 = "Could not find any plugins with that command.";
        internal static readonly string MULTIPLE_PLUGINS_WITH_COMMAND           = "Found {0} plugin(s) with that command, please specify which you mean: {1}";

        //Plugins strings

        internal static readonly string PLUGIN_NOT_FOUND                        = "Could not find plugin with the name '{0}'.";
        internal static readonly string PLUGIN_STILL_LOADED_UNINSTALL           = "The plugin cannot be uninstalled as it is currently loaded.";
        internal static readonly string TYPE_NOT_PLUGIN                         = "The type supplied was not a plugin!";
        internal static readonly string TYPE_ABSTRACT                           = "Cannot create an instance of an abstract type.";

        //File strings

        internal static readonly string FILE_NOT_LIBRARY                        = "The filepath supplied was not a DLL library.";
        internal static readonly string FILE_DOES_NOT_EXIST                     = "The specified filepath does not exist.";

        //ServerSpawnData strings

        internal static readonly string XML_SERVER_INVALID_ROOT                 = "Server data must be contained in a <server> element.";
        internal static readonly string XML_SERVER_ADDRESS_INVALID              = "<server> address attribute not a valid IP address.";
        internal static readonly string XML_SERVER_ADDRESS_MISSING              = "<server> element must have an address attribute.";
        internal static readonly string XML_SERVER_PORT_INVALID                 = "<server> port attribute not a valid number.";
        internal static readonly string XML_SERVER_PORT_MISSING                 = "<server> element must have a port attribute.";
        internal static readonly string XML_SERVER_PROTOCOLTYPE_INVALID         = "<server> protocoltype attribute not a valid transport protocol type.";
        internal static readonly string XML_SERVER_PROTOCOLTYPE_MISSING         = "<server> element must have a protocoltype attribute.";
        internal static readonly string XML_SERVER_IPVERSION_INVALID            = "<server> ipVersion attribute not a valid IP version.";
        internal static readonly string XML_SERVER_IPVERSION_MISSING            = "<server> element must have an ipVersion attribute.";
        internal static readonly string XML_SERVER_NO_DELAY_INVALID             = "<server> noDelay attribute not a valid boolean.";
        internal static readonly string XML_SERVER_MAXSTRIKES_INVALID           = "<server> maxStrikes attribute not a valid number.";
        internal static readonly string XML_SERVER_MAXSTRIKES_MISSING           = "<server> element must have a maxStrikes attribute.";
        internal static readonly string XML_SERVER_USE_FALLBACK_INVALID         = "<server> useFallback attribute not a valid boolean.";
        internal static readonly string XML_PLUGINSEARCH_INVALID_ROOT           = "PluginSearch settings must be contained in a <pluginSearch> element.";
        internal static readonly string XML_PLUGINSEARCHPATH_SRC_MISSING        = "<pluginSearchPath> element must have an src attribute.";
        internal static readonly string XML_PLUGINSEARCHPATH_CREATEDIR_INVALID  = "<pluginSearchPath> createDir attribute not a valid boolean.";
        internal static readonly string XML_DATA_INVALID_ROOT                   = "Data settings must be contained in a <data> element.";
        internal static readonly string XML_DATA_DIRECTORY_MISSING              = "<data> elements must have a directory attribute.";
        internal static readonly string XML_LOGGING_INVALID_ROOT                = "Logging data must be contained in a <logging> element.";
        internal static readonly string XML_LOGGING_LOGWRITERS_MISSING          = "Logging elment must define a <logWriters> element.";
        internal static readonly string XML_LOGWRITER_INVALID_ROOT              = "LogWriter data must be contained in a <logWriter> element.";
        internal static readonly string XML_LOGWRITER_NAME_MISSING              = "<logWriter> elements must have a name attribute.";
        internal static readonly string XML_LOGWRITER_TYPE_MISSING              = "<logWriter> elements must have a type attribute.";
        internal static readonly string XML_LOGWRITER_LEVELS_MISSING            = "<logWriters> elements must have a levels attribute.";
        internal static readonly string XML_DATACONNECTORS_INVALID_ROOT         = "DataConnectors must be contained in a <dataConnectors> element.";
        internal static readonly string XML_DATACONNECTORS_LOADBYDEFAULT_INVALID = "<dataConnectors> loadByDefault attribute not a valid boolean.";
        internal static readonly string XML_DATACONNECTOR_INVALID_ROOT          = "Data connector data must be contained in a <dataConnectors> element.";
        internal static readonly string XML_DATACONNECTOR_TYPE_MISSING          = "<dataConnector> elements must contain a type attribute.";
        internal static readonly string XML_DATACONNECTOR_LOAD_INVALID          = "<dataConnector> load attribute not a valid boolean.";
        internal static readonly string XML_PLUGINS_INVALID_ROOT                = "Plugins must be contained in a <plugins> element.";
        internal static readonly string XML_PLUGINS_LOADBYDEFAULT_INVALID       = "<plugins> loadByDefault attribute not a valid boolean.";
        internal static readonly string XML_PLUGIN_INVALID_ROOT                 = "Plugin data must be contained in a <plugin> element.";
        internal static readonly string XML_PLUGIN_TYPE_MISSING                 = "<plugin> elements must contain a type attribute.";
        internal static readonly string XML_PLUGIN_LOAD_INVALID                 = "<plugin> load attribute not a valid boolean.";
        internal static readonly string XML_DATABASES_INVALID_ROOT              = "Databases must be contained in a <databases> element.";
        internal static readonly string XML_DATABASES_NAME_MISSING              = "<database> elements must contain a name attribute.";
        internal static readonly string XML_DATABASES_PROVIDER_MISSING          = "<database> elements must contain a providerName attribute.";
        internal static readonly string XML_DATABASES_CONNECTIONSTRING_MISSING  = "<database> elements must contain a connectionString attribute.";
        internal static readonly string XML_CACHE_INVALID_ROOT                  = "Cache settings must be contained in a <cache> element.";
        internal static readonly string XML_CACHE_WRITERS_INVALID               = "<cache> maxCachedWriters attribute not a valid number.";
        internal static readonly string XML_CACHE_READERS_INVALID               = "<cache> maxCachedReaders attribute not a valid number.";
        internal static readonly string XML_CACHE_MESSAGES_INVALID              = "<cache> maxCachedMessages attribute not a valid number.";
        internal static readonly string XML_CACHE_SAEA_INVALID                  = "<cache> maxCachedSocketAsyncEventArgs attribute not a valid number.";
        internal static readonly string XML_CACHE_ADT_INVALID                   = "<cache> maxActionDispatcherTasks attribute not a valid number.";
        internal static readonly string XML_LISTENERS_INVALID_ROOT              = "Listeners must be contained in a <listeners> element.";
        internal static readonly string XML_LISTENER_INVALID_ROOT               = "Listener data must be contained in a <listener> element.";
        internal static readonly string XML_LISTENER_TYPE_MISSING               = "<listener> elements must contains a type attribute.";
        internal static readonly string XML_LISTENER_NAME_MISSING               = "<listener> elements must contain a name attribute.";
    }
}
