﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     An exception raised for invalid XML configuration files.
    /// </summary>
    [Serializable]
    public class XmlConfigurationException : Exception
    {
        /// <summary>
        ///     Create and new exception for XML configurations with a message.
        /// </summary>
        /// <param name="msg">The message for the exception.</param>
        public XmlConfigurationException(string msg) : base(msg) { }

        /// <summary>
        ///     Create and new exception for XML configurations with a message and inner exception.
        /// </summary>
        /// <param name="msg">The message for the exception.</param>
        /// <param name="innerException">The inner exception.</param>
        public XmlConfigurationException(string msg, Exception innerException) : base(msg, innerException) { }
    }
}
