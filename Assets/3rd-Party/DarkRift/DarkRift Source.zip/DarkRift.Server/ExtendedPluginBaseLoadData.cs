﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    public abstract class ExtendedPluginBaseLoadData : PluginBaseLoadData
    {
        /// <summary>
        ///     The handler for writing events.
        /// </summary>
        public WriteEventHandler WriteEventHandler { get; set; }

        internal ExtendedPluginBaseLoadData(string name, DarkRiftServer server, NameValueCollection settings, WriteEventHandler writeEventHandler)
            : base(name, server, settings)
        {
            WriteEventHandler = writeEventHandler;
        }

        public ExtendedPluginBaseLoadData(string name, NameValueCollection settings, DarkRiftInfo serverInfo, DarkRiftThreadHelper threadHelper, WriteEventHandler writeEventHandler)
            : base(name, settings, serverInfo, threadHelper)
        {
            WriteEventHandler = writeEventHandler;
        }
    }
}
