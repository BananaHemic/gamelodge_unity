﻿using System;
using System.Collections.Specialized;

namespace DarkRift.Server
{
    /// <summary>
    ///     Data related to the listener's loading.
    /// </summary>
    public sealed class NetworkListenerLoadData : ExtendedPluginBaseLoadData
    {
        /// <summary>
        ///     The network listener manager to pass to the listener.
        /// </summary>
        public INetworkListenerManager NetworkListenerManager { get; set; }

        internal NetworkListenerLoadData(string name, DarkRiftServer server, NameValueCollection settings, WriteEventHandler writeEventHandler)
            : base(name, server, settings, writeEventHandler)
        {
            this.NetworkListenerManager = server.NetworkListenerManager;
        }

        public NetworkListenerLoadData(string name, NameValueCollection settings, DarkRiftInfo serverInfo, DarkRiftThreadHelper threadHelper, WriteEventHandler writeEventHandler)
            : base(name, settings, serverInfo, threadHelper, writeEventHandler)
        {
        }
    }
}