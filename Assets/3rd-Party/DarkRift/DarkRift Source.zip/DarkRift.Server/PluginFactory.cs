﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Factory for creating plugins of various types.
    /// </summary>
    sealed class PluginFactory
    {
        /// <summary>
        ///     The list of types that can be loaded.
        /// </summary>
        Dictionary<string, Type> types = new Dictionary<string, Type>();
        
        /// <summary>
        ///     The DarRiftServer that owns this PluginManager.
        /// </summary>
        DarkRiftServer server;

        /// <summary>
        ///     Creates a new PluginFactory.
        /// </summary>
        /// <param name="server">The server that owns this plugin factory.</param>
        internal PluginFactory(DarkRiftServer server)
        {
            this.server = server;
        }

        /// <summary>
        ///     Adds plugins based on the plugins settings supplied.
        /// </summary>
        /// <param name="settings">The settings defining where to find plugins.</param>
        internal void AddFromSettings(ServerSpawnData.PluginSearchSettings settings)
        {
            AddTypes(settings.PluginTypes);

            foreach (ServerSpawnData.PluginSearchSettings.PluginSearchPath path in settings.PluginSearchPaths)
            {
                if (File.Exists(path.Source))
                    AddFile(path.Source);
                else
                    AddDirectory(path.Source, path.CreateDirectory);
            }
        }

        /// <summary>
        ///     Adds a directory of plugin files to the index.
        /// </summary>
        /// <param name="directory">The directory to add.</param>
        /// <param name="create">Whether to create the directory if not present.</param>
        internal void AddDirectory(string directory, bool create)
        {
            //Create plugin directory if not present
            if (Directory.Exists(directory))
            {
                //Get the names of all files to try and load
                string[] pluginSourceFiles = Directory.GetFiles(directory, "*.dll", SearchOption.AllDirectories);

                AddFiles(pluginSourceFiles);
            }
            else
            {
                if (create)
                    Directory.CreateDirectory(directory);
            }
        }

        /// <summary>
        ///     Adds the given plugin files into the index.
        /// </summary>
        /// <param name="files">An array of filepaths to the plugins.</param>
        internal void AddFiles(IEnumerable<string> files)
        {
            //Load each file to a plugin
            foreach (string pluginSourceFile in files)
                AddFile(pluginSourceFile);
        }

        /// <summary>
        ///     Adds plugins into the server from the given types.
        /// </summary>
        /// <param name="pluginTypes">The types of plugins to add.</param>
        internal void AddTypes(IEnumerable<Type> pluginTypes)
        {
            foreach (Type pluginType in pluginTypes)
                AddType(pluginType);
        }

        /// <summary>
        ///     Adds all plugin types in the file to the index.
        /// </summary>
        /// <param name="file">The file containing the types.</param>
        internal void AddFile(string file)
        {
            //Check the file is a dll
            if (Path.GetExtension(file) != ".dll")
                throw new ArgumentException(ErrorStrings.FILE_NOT_LIBRARY);

            //Check the file exists
            if (!File.Exists(file))
                throw new FileNotFoundException(ErrorStrings.FILE_DOES_NOT_EXIST);

            //Log
            server.InternalLogManager.WriteEvent(nameof(PluginFactory), $"Searching '{file}' for plugins.", LogType.Trace);

            //Load the assembly
            Assembly assembly;
            try
            {
                assembly = Assembly.LoadFrom(Path.GetFullPath(file));
            }
            catch (Exception e)
            {
                server.InternalLogManager.WriteEvent(nameof(PluginFactory), $"{file} could not be loaded as an exception occurred.", LogType.Error, e);
                return;
            }

            //Get the types in the assembly
            Type[] enclosedTypes;
            try
            {
                enclosedTypes = assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException e)
            {
                server.InternalLogManager.WriteEvent(
                    nameof(PluginFactory),
                    $"Failed to load one or more plugins from DLL file '{file}', see trace for exception and more info. Rebuilding plugin may help.",
                    LogType.Error,
                    e
                );

                foreach (Exception loaderException in e.LoaderExceptions)
                {
                    server.InternalLogManager.WriteEvent(
                        nameof(PluginFactory),
                        "Additional exception detail from LoaderExceptions property.",
                        LogType.Trace,
                        loaderException
                    );
                }

                enclosedTypes = e.Types;
            }

            //Find the types that are plugins
            foreach (Type enclosedType in enclosedTypes)
            {
                if (enclosedType.IsSubclassOf(typeof(PluginBase)) && !enclosedType.IsAbstract)
                {
                    //Add the plugin
                    AddType(enclosedType);
                }
            }
        }

        /// <summary>
        ///     Adds a type to the lookup.
        /// </summary>
        /// <param name="plugin">The plugin type to add.</param>
        internal void AddType(Type plugin)
        {
            if (!plugin.IsSubclassOf(typeof(PluginBase)))
                throw new ArgumentException(ErrorStrings.TYPE_NOT_PLUGIN);

            if (plugin.IsAbstract)
                throw new ArgumentException(ErrorStrings.TYPE_ABSTRACT);

            try
            {
                types.Add(plugin.Name, plugin);
            }
            catch (ArgumentException)
            {
                server.InternalLogManager.WriteEvent(
                    nameof(PluginFactory),
                    "A plugin named " + plugin.Name + "could not be added to the factory as it was already present.",
                    LogType.Error
                );
            }
        }

        /// <summary>
        ///     Creates a named type as a specified plugin.
        /// </summary>
        /// <typeparam name="T">The type of plugin to load it as.</typeparam>
        /// <param name="type">The name of the type to load.</param>
        /// <param name="loadData">The data to load into the plugin.</param>
        /// <param name="backupLoadData">The backup load data to try for backwards compatablity.</param>
        /// <returns>The new plugin.</returns>
        internal T Create<T>(string type, PluginBaseLoadData loadData, PluginLoadData backupLoadData = null) where T : PluginBase
        {
            return Create<T>(types[type], loadData, backupLoadData);
        }

        /// <summary>
        ///     Creates a type as a specified plugin.
        /// </summary>
        /// <typeparam name="T">The type of plugin to load it as.</typeparam>
        /// <param name="type">The type to load.</param>
        /// <param name="loadData">The data to load into the plugin.</param>
        /// <param name="backupLoadData">The backup load data to try for backwards compatability.</param>
        /// <returns>The new plugin.</returns>
        internal T Create<T>(Type type, PluginBaseLoadData loadData, PluginLoadData backupLoadData = null) where T : PluginBase
        {
            //Create an instance of the plugin
            T plugin;
            try
            {
                plugin = (T)Activator.CreateInstance(type, loadData);
            }
            catch (MissingMethodException)
            {
                //Failed, perhaps using backup PluginLoadData would help?
                if (backupLoadData != null)
                {
                    plugin = (T)Activator.CreateInstance(type, backupLoadData);
                    server.InternalLogManager.WriteEvent(nameof(PluginFactory), "Reverted to loading plugin with backup PluginLoadData object, ensure this plugin has a constructor accepting a " + loadData.GetType().Name + ".", LogType.Warning);
                }
                else
                {
                    throw;
                }
            }

            //Log creation
            if (!plugin.Hidden)
                server.InternalLogManager.WriteEvent(nameof(PluginFactory), $"Created plugin '{type.Name}'.", LogType.Trace);
            
            return plugin;
        }

        /// <summary>
        ///     Returns a list of plugins found that are subtypes of that given.
        /// </summary>
        /// <param name="type">The type to filter by.</param>
        /// <returns>The types found.</returns>
        internal Type[] GetAllSubtypes(Type type)
        {
            return types.Values
                .Where(t => t.IsSubclassOf(type))
                .ToArray();
        }
    }
}
