﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Xml;
using System.Configuration;
using System.IO;

using System.Net;
using System.Collections.Specialized;

namespace DarkRift.Server
{
    /// <summary>
    ///     Details of how to start a new server.
    /// </summary>
    [Serializable]
    public class ServerSpawnData
    {
        /// <summary>
        ///     The general settings for the server.
        /// </summary>
        public ServerSettings Server = new ServerSettings();

        /// <summary>
        ///     The locations to search for plugins in.
        /// </summary>
        public PluginSearchSettings PluginSearch = new PluginSearchSettings();

        /// <summary>
        ///     The settings for the data handler plugins and general persistent storage.
        /// </summary>
        public DataSettings Data = new DataSettings();

        /// <summary>
        ///     The settings for the log writer plugins and general logging.
        /// </summary>
        public LoggingSettings Logging = new LoggingSettings();
        
        /// <summary>
        ///     The settings for resolving and loading plugins.
        /// </summary>
        public PluginsSettings Plugins = new PluginsSettings();

        /// <summary>
        ///     The settings for database connections.
        /// </summary>
        public DatabaseSettings Databases = new DatabaseSettings();

        /// <summary>
        ///     The settings for the object cache.
        /// </summary>
        public CacheSettings Cache = new CacheSettings();

        /// <summary>
        ///     The settings for the server's listeners.
        /// </summary>
        public ListenersSettings Listeners = new ListenersSettings();

        /// <summary>
        ///     Whether events are executed through the dispatcher or not.
        /// </summary>
        public bool EventsFromDispatcher { get; set; }

        /// <summary>
        ///     Holds settings related to the overall server.
        /// </summary>
        [Serializable]
        public class ServerSettings
        {
            /// <summary>
            ///     The address the server will listen on.
            /// </summary>
            [Obsolete("Address is obsolete, use listeners system instead. These properties will only have effect if no listeners are defined.")]
            public IPAddress Address { get; set; }

            /// <summary>
            ///     The port number that the server should listen on.
            /// </summary>
            [Obsolete("Port is obsolete, use listeners system instead. These properties will only have effect if no listeners are defined.")]
            public ushort Port { get; set; }

            /// <summary>
            ///     The IP version to host the server on.
            /// </summary>
            [Obsolete("IPVersion is obsolete, use listeners system instead. These properties will only have effect if no listeners are defined.")]
            public IPVersion IPVersion { get; set; }

            /// <summary>
            ///     Whether to disable Nagle's algorithm.
            /// </summary>
            [Obsolete("NoDelay is obsolete, use listeners system instead. These properties will only have effect if no listeners are defined.")]
            public bool NoDelay { get; set; }

            /// <summary>
            ///     The number of strikes that can be received before the client is automatically kicked.
            /// </summary>
            public byte MaxStrikes { get; set; }

            /// <summary>
            ///     Whether the fallback networking system should be used for compatability with Unity.
            /// </summary>
            [Obsolete("UseFallbackNetworking is obsolete, use CombatabilityBichannelListener instead. These properties will only have effect if no listeners are defined.")]
            public bool UseFallbackNetworking { get; set; }

            /// <summary>
            ///     Loads the server settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "server")
                    throw new XmlConfigurationException(ErrorStrings.XML_SERVER_INVALID_ROOT);

                //Read address
                Address = helper.ReadIPAttributeOrDefault(
                    element, 
                    "address", 
                    ErrorStrings.XML_SERVER_ADDRESS_INVALID,
                    IPAddress.Any
                );

                //Read port
                Port = helper.ReadUInt16AttributeOrDefault(
                    element,
                    "port",
                    ErrorStrings.XML_SERVER_PORT_INVALID,
                    4296
                );

                //Read the ip type
                IPVersion = helper.ReadIPVersionAttributeOrDefault(
                    element,
                    "ipVersion",
                    ErrorStrings.XML_SERVER_IPVERSION_INVALID,
                    IPVersion.IPv4
                );

                //Read no delay
                NoDelay = helper.ReadBooleanAttribute(
                    element,
                    "noDelay",
                    ErrorStrings.XML_SERVER_NO_DELAY_INVALID,
                    false
                );

                //Read max strikes
                MaxStrikes = helper.ReadByteAttribute(
                    element,
                    "maxStrikes",
                    ErrorStrings.XML_SERVER_MAXSTRIKES_MISSING,
                    ErrorStrings.XML_SERVER_MAXSTRIKES_INVALID
                );

                //Read use fallback networking
                UseFallbackNetworking  = helper.ReadBooleanAttribute(
                    element,
                    "useFallback",
                    ErrorStrings.XML_SERVER_USE_FALLBACK_INVALID,
                    false
                );
            }
        }

        /// <summary>
        ///     Holds the paths to search for plugins from.
        /// </summary>
        [Serializable]
        public class PluginSearchSettings
        {
            /// <summary>
            ///     The paths to search.
            /// </summary>
            public List<PluginSearchPath> PluginSearchPaths { get; } = new List<PluginSearchPath>();

            /// <summary>
            ///     Individual types of plugins that should be loaded.
            /// </summary>
            public List<Type> PluginTypes { get; } = new List<Type>();

            /// <summary>
            ///     A path to search.
            /// </summary>
            public class PluginSearchPath
            {
                /// <summary>
                ///     The path.
                /// </summary>
                public string Source { get; set; }

                /// <summary>
                ///     Whether the directory should be created if missing.
                /// </summary>
                /// <remarks>This has no effect when the path is a file.</remarks>
                public bool CreateDirectory { get; set; }

                /// <summary>
                ///     Loads the path from the specified XML element.
                /// </summary>
                /// <param name="element">The XML element to load from.</param>
                /// <param name="helper">The XML configuration helper being used.</param>
                internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
                {
                    //Read source
                    Source = helper.ReadStringAttribute(
                        element,
                        "src",
                        ErrorStrings.XML_PLUGINSEARCHPATH_SRC_MISSING
                    );

                    //Read port
                    CreateDirectory = helper.ReadBooleanAttribute(
                        element,
                        "createDir",
                        ErrorStrings.XML_PLUGINSEARCHPATH_CREATEDIR_INVALID,
                        false
                    );
                }
            }

            /// <summary>
            ///     Loads the server settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "pluginSearch")
                    throw new XmlConfigurationException(ErrorStrings.XML_PLUGINSEARCH_INVALID_ROOT);

                //Read search paths
                helper.ReadElementCollectionTo(
                    element, 
                    "pluginSearchPath", 
                    e =>
                    {
                        PluginSearchPath psp = new PluginSearchPath();
                        psp.LoadFromXmlElement(e, helper);
                        return psp;
                    },
                    PluginSearchPaths
                );
            }
        }

        /// <summary>
        ///     Holds settings for persistent data storage.
        /// </summary>
        [Serializable]
        public class DataSettings
        {
            /// <summary>
            ///     The directory to store data in.
            /// </summary>
            public string Directory { get; set; } = "Data/";
            
            /// <summary>
            ///     Loads the server settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "data")
                    throw new XmlConfigurationException(ErrorStrings.XML_DATA_INVALID_ROOT);

                //Read data directory
                Directory = helper.ReadStringAttribute(
                    element,
                    "directory",
                    ErrorStrings.XML_DATA_DIRECTORY_MISSING
                );
            }
        }

        /// <summary>
        ///     Holds settings related to loading the logging system.
        /// </summary>
        [Serializable]
        public class LoggingSettings
        {
            /// <summary>
            ///     The log writers to use.
            /// </summary>
            public List<LogWriterSettings> LogWriters { get; } = new List<LogWriterSettings>();

            /// <summary>
            ///     Holds settings about a log writer.
            /// </summary>
            [Serializable]
            public class LogWriterSettings
            {
                /// <summary>
                ///     The name of the log writer.
                /// </summary>
                public string Name { get; set; }

                /// <summary>
                ///     The type of log writer.
                /// </summary>
                public string Type { get; set; }

                /// <summary>
                ///     The types of logs to be directed to this writer.
                /// </summary>
                public LogType[] LogLevels { get; set; }

                /// <summary>
                ///     Settings that should be loaded for this writer.
                /// </summary>
                public NameValueCollection Settings { get; } = new NameValueCollection();

                /// <summary>
                ///     Creates a new LoggingSettings object.
                /// </summary>
                public LogWriterSettings()
                {

                }

                /// <summary>
                ///     Loads the log writer settings from the specified XML element.
                /// </summary>
                /// <param name="element">The XML element to load from.</param>
                /// <param name="helper">The XML configuration helper being used.</param>
                internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
                {
                    if (element == null || element.Name != "logWriter")
                        throw new XmlConfigurationException(ErrorStrings.XML_LOGWRITER_INVALID_ROOT);

                    Type = helper.ReadStringAttribute(
                        element,
                        "type",
                        ErrorStrings.XML_LOGWRITER_TYPE_MISSING
                    );

                    Name = helper.ReadStringAttribute(
                        element,
                        "name",
                        ErrorStrings.XML_LOGWRITER_NAME_MISSING
                    );

                    string levelString = helper.ReadStringAttribute(
                        element,
                        "levels",
                        ErrorStrings.XML_LOGWRITER_LEVELS_MISSING
                    );

                    LogLevels = levelString
                        .ToLower()
                        .Split(',')
                        .Select(l => ParseLogType(l))
                        .ToArray();

                    helper.ReadAttributeCollectionTo(
                        element.Element("settings"),
                        Settings
                    );
                }

                /// <summary>
                ///     Parses a string to a log type.
                /// </summary>
                /// <param name="logType">The type to parse</param>
                /// <returns>The parsed type.</returns>
                private LogType ParseLogType(string logType)
                {
                    switch (logType.Trim().ToLower())
                    {
                        case "trace":
                            return LogType.Trace;
                        case "info":
                            return LogType.Info;
                        case "warning":
                            return LogType.Warning;
                        case "error":
                            return LogType.Error;
                        case "fatal":
                            return LogType.Fatal;
                        default:
                            throw new XmlConfigurationException("Unknown log level.");
                    }
                }
            }

            /// <summary>
            ///     Creates a new LoggingSettings object.
            /// </summary>
            public LoggingSettings()
            {

            }

            /// <summary>
            ///     Loads the logging settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "logging")
                    throw new XmlConfigurationException(ErrorStrings.XML_LOGGING_INVALID_ROOT);

                //Load writers
                var logWriters = element.Element("logWriters");

                if (logWriters == null)
                    throw new XmlConfigurationException(ErrorStrings.XML_LOGGING_LOGWRITERS_MISSING);

                helper.ReadElementCollectionTo(
                    logWriters,
                    "logWriter",
                    e => {
                        LogWriterSettings s = new LogWriterSettings();
                        s.LoadFromXmlElement(e, helper);
                        return s;
                    },
                    LogWriters
                );
            }
        }
        
        /// <summary>
        ///     Handles the settings for plugins.
        /// </summary>
        [Serializable]
        public class PluginsSettings
        {
            /// <summary>
            ///     The action to perform on all unlisted plugins.
            /// </summary>
            public bool LoadByDefault { get; set; }

            /// <summary>
            ///     The list of plugins to load.
            /// </summary>
            public List<PluginSettings> Plugins { get; } = new List<PluginSettings>();

            /// <summary>
            ///     Holds settings about a plugin.
            /// </summary>
            [Serializable]
            public class PluginSettings
            {
                /// <summary>
                ///     The type of plugin.
                /// </summary>
                public string Type { get; set; }

                /// <summary>
                ///     Whether to load or ignore this plugin.
                /// </summary>
                public bool Load { get; set; } = true;

                /// <summary>
                ///     Settings that should be loaded for this writer.
                /// </summary>
                public NameValueCollection Settings { get; } = new NameValueCollection();

                /// <summary>
                ///     Loads the plugin settings from the specified XML element.
                /// </summary>
                /// <param name="element">The XML element to load from.</param>
                /// <param name="helper">The XML configuration helper being used.</param>
                internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
                {
                    if (element == null || element.Name != "plugin")
                        throw new XmlConfigurationException(ErrorStrings.XML_PLUGIN_INVALID_ROOT);

                    //Type attribute.
                    Type = helper.ReadStringAttribute(
                        element,
                        "type",
                        ErrorStrings.XML_PLUGIN_TYPE_MISSING
                    );
                    
                    //Load attribute.
                    Load = helper.ReadBooleanAttribute(
                        element,
                        "load",
                        ErrorStrings.XML_PLUGIN_LOAD_INVALID,
                        true
                    );

                    helper.ReadAttributeCollectionTo(
                        element.Element("settings"),
                        Settings
                    );
                }
            }
            
            /// <summary>
            ///     Loads the plugins settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "plugins")
                    throw new XmlConfigurationException(ErrorStrings.XML_PLUGINS_INVALID_ROOT);

                //LoadByDefault attribute.
                LoadByDefault = helper.ReadBooleanAttribute(
                    element,
                    "loadByDefault",
                    ErrorStrings.XML_PLUGINS_LOADBYDEFAULT_INVALID,
                    false
                );

                //Load plugins
                helper.ReadElementCollectionTo(
                    element,
                    "plugin",
                    e =>
                    {
                        PluginSettings pluginSettings = new PluginSettings();
                        pluginSettings.LoadFromXmlElement(e, helper);
                        return pluginSettings;
                    },
                    Plugins
                );
            }
        }

        /// <summary>
        ///     Holds settings related to loading databases for plugins.
        /// </summary>
        [Serializable]
        public class DatabaseSettings
        {
            /// <summary>
            ///     The databases to connect to.
            /// </summary>
            public List<DatabaseConnectionData> Databases { get; } = new List<DatabaseConnectionData>();

            /// <summary>
            ///     Holds data relating to a specific connection.
            /// </summary>
            [Serializable]
            public class DatabaseConnectionData
            {
                /// <summary>
                ///     The name of the connection.
                /// </summary>
                public string Name { get; set; }

                /// <summary>
                ///     The connection string to create the connection with.
                /// </summary>
                public string ConnectionString { get; set; }

                /// <summary>
                ///     Creates a new Database Connection data object.
                /// </summary>
                /// <param name="name">The name of the connection.</param>
                /// <param name="connectionString">The connection string for the connection.</param>
                public DatabaseConnectionData(string name, string connectionString)
                {
                    this.Name = name;
                    this.ConnectionString = connectionString;
                }
            }

            /// <summary>
            ///     Loads the database settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "databases")
                    throw new XmlConfigurationException(ErrorStrings.XML_DATABASES_INVALID_ROOT);

                //Load databases
                helper.ReadElementCollectionTo(
                    element,
                    "database",
                    e =>
                    {
                        string name = helper.ReadStringAttribute(
                            e,
                            "name",
                            ErrorStrings.XML_DATABASES_NAME_MISSING
                        );

                        string connectionString = helper.ReadStringAttribute(
                            e,
                            "connectionString",
                            ErrorStrings.XML_DATABASES_CONNECTIONSTRING_MISSING
                        );
                        
                        return new DatabaseConnectionData(
                            name,
                            connectionString
                        );
                    },
                    Databases
                );
            }
        }

        /// <summary>
        ///     Holds settings related to the object cache.
        /// </summary>
        [Serializable]
        public class CacheSettings
        {
            /// <summary>
            ///     The maximum number of <see cref="DarkRiftWriter"/> instances stored per thread.
            /// </summary>
            public int MaxCachedWriters { get; set; }

            /// <summary>
            ///     The maximum number of <see cref="DarkRiftReader"/> instances stored per thread.
            /// </summary>
            public int MaxCachedReaders { get; set; }

            /// <summary>
            ///     The maximum number of <see cref="Message"/> instances stored per thread.
            /// </summary>
            public int MaxCachedMessages { get; set; }

            /// <summary>
            ///     The maximum number of <see cref="System.Net.Sockets.SocketAsyncEventArgs"/> instances stored per thread.
            /// </summary>
            public int MaxCachedSocketAsyncEventArgs { get; set; }

            /// <summary>
            ///     The maximum number of <see cref="DarkRift.Dispatching.ActionDispatcherTask"/> instances stored per thread.
            /// </summary>
            public int MaxActionDispatcherTasks { get; set; }

            /// <summary>
            ///     Loads the cache settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null)
                    return;

                if (element.Name != "cache")
                    throw new XmlConfigurationException(ErrorStrings.XML_CACHE_INVALID_ROOT);
                
                MaxCachedWriters = helper.ReadUInt16AttributeOrDefault(element, "maxCachedWriters", ErrorStrings.XML_CACHE_WRITERS_INVALID, 4);
                MaxCachedReaders = helper.ReadUInt16AttributeOrDefault(element, "maxCachedReaders", ErrorStrings.XML_CACHE_READERS_INVALID, 4);
                MaxCachedMessages = helper.ReadUInt16AttributeOrDefault(element, "maxCachedMessages", ErrorStrings.XML_CACHE_MESSAGES_INVALID, 4);
                MaxCachedSocketAsyncEventArgs = helper.ReadUInt16AttributeOrDefault(element, "maxCachedSocketAsyncEventArgs", ErrorStrings.XML_CACHE_SAEA_INVALID, 32);
                MaxActionDispatcherTasks = helper.ReadUInt16AttributeOrDefault(element, "maxActionDispatcherTasks", ErrorStrings.XML_CACHE_ADT_INVALID, 16);
            }
        }

        /// <summary>
        ///     Holds settings related to loading the listeners system.
        /// </summary>
        [Serializable]
        public class ListenersSettings
        {
            /// <summary>
            ///     The listeners to use.
            /// </summary>
            public List<NetworkListenerSettings> NetworkListeners { get; } = new List<NetworkListenerSettings>();

            /// <summary>
            ///     Holds settings about a network listener.
            /// </summary>
            [Serializable]
            public class NetworkListenerSettings
            {
                /// <summary>
                ///     The name of the listener.
                /// </summary>
                public string Name { get; set; }

                /// <summary>
                ///     The type of listener.
                /// </summary>
                public string Type { get; set; }
                
                /// <summary>
                ///     Settings that should be loaded for this listener.
                /// </summary>
                public NameValueCollection Settings { get; } = new NameValueCollection();

                /// <summary>
                ///     Creates a new NetworkListenerSettings object.
                /// </summary>
                public NetworkListenerSettings()
                {

                }

                /// <summary>
                ///     Loads the listener settings from the specified XML element.
                /// </summary>
                /// <param name="element">The XML element to load from.</param>
                /// <param name="helper">The XML configuration helper being used.</param>
                internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
                {
                    if (element == null || element.Name != "listener")
                        throw new XmlConfigurationException(ErrorStrings.XML_LISTENER_INVALID_ROOT);

                    Type = helper.ReadStringAttribute(
                        element,
                        "type",
                        ErrorStrings.XML_LISTENER_TYPE_MISSING
                    );

                    Name = helper.ReadStringAttribute(
                        element,
                        "name",
                        ErrorStrings.XML_LISTENER_NAME_MISSING
                    );
                    
                    helper.ReadAttributeCollectionTo(
                        element.Element("settings"),
                        Settings
                    );
                }
            }

            /// <summary>
            ///     Creates a new ListenerSettings object.
            /// </summary>
            public ListenersSettings()
            {

            }

            /// <summary>
            ///     Loads the listener settings from the specified XML element.
            /// </summary>
            /// <param name="element">The XML element to load from.</param>
            /// <param name="helper">The XML configuration helper being used.</param>
            internal void LoadFromXmlElement(XElement element, ConfigurationFileHelper helper)
            {
                if (element == null || element.Name != "listeners")
                    throw new XmlConfigurationException(ErrorStrings.XML_LISTENERS_INVALID_ROOT);
                
                helper.ReadElementCollectionTo(
                    element,
                    "listener",
                    e => {
                        NetworkListenerSettings s = new NetworkListenerSettings();
                        s.LoadFromXmlElement(e, helper);
                        return s;
                    },
                    NetworkListeners
                );
            }
        }

        /// <summary>
        ///     Creates a server spawn data from specified XML configuration file.
        /// </summary>
        /// <param name="filePath">The path of the XML file.</param>
        /// <param name="variables">The variables to inject into the configuration.</param>
        /// <returns>The ServerSpawnData created.</returns>
        public static ServerSpawnData CreateFromXml(string filePath, NameValueCollection variables)
        {
            return CreateFromXml(XDocument.Load(filePath), variables);
        }

        /// <summary>
        ///     Creates a server spawn data from specified XML configuration file.
        /// </summary>
        /// <param name="document">The XML file.</param>
        /// <param name="variables">The variables to inject into the configuration.</param>
        /// <returns>The ServerSpawnData created.</returns>
        public static ServerSpawnData CreateFromXml(XDocument document, NameValueCollection variables)
        {
            //Create a new server spawn data.
            ServerSpawnData spawnData = new ServerSpawnData();

            ConfigurationFileHelper helper = new ConfigurationFileHelper(variables);

            XElement root = document.Root;

            spawnData.Server.LoadFromXmlElement(root.Element("server"), helper);
            spawnData.PluginSearch.LoadFromXmlElement(root.Element("pluginSearch"), helper);
            spawnData.Data.LoadFromXmlElement(root.Element("data"), helper);
            spawnData.Logging.LoadFromXmlElement(root.Element("logging"), helper);
            spawnData.Plugins.LoadFromXmlElement(root.Element("plugins"), helper);
            spawnData.Databases.LoadFromXmlElement(root.Element("databases"), helper);
            spawnData.Cache.LoadFromXmlElement(root.Element("cache"), helper);
            spawnData.Listeners.LoadFromXmlElement(root.Element("listeners"), helper);

            //Return the new spawn data!
            return spawnData;
        }

        ServerSpawnData()
        {

        }

        /// <summary>
        ///     Creates a new server spawn data with necessary settings.
        /// </summary>
        /// <param name="address">The address the server should listen on.</param>
        /// <param name="port">The port the server should listen on.</param>
        /// <param name="ipVersion">The IP protocol the server should listen on.</param>
        public ServerSpawnData(IPAddress address, ushort port, IPVersion ipVersion)
        {
            this.Server.Address = address;
            this.Server.Port = port;
            this.Server.IPVersion = ipVersion;
        }
    }
}
