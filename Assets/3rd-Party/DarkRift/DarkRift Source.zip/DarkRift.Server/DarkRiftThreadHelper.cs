﻿using DarkRift.Dispatching;
using System;

namespace DarkRift.Server
{
    /// <summary>
    ///     Thread helper class for DarkRift.
    /// </summary>
    public class DarkRiftThreadHelper
    {
        /// <summary>
        ///     Whether events are executed through the dispatcher or not.
        /// </summary>
        public bool EventsFromDispatcher { get; set; }

        /// <summary>
        ///     The dispatcher for the server.
        /// </summary>
        public IDispatcher Dispatcher { get; set; }

        /// <summary>
        ///     Creates a new thread helper with the given invocation settings.
        /// </summary>
        /// <param name="eventsFromDispatcher">Whether events should be invoked from the dispatcher.</param>
        /// <param name="dispatcher">The dispatcher to use.</param>
        public DarkRiftThreadHelper(bool eventsFromDispatcher, Dispatcher dispatcher)
        {
            EventsFromDispatcher = eventsFromDispatcher;
            Dispatcher = dispatcher;
        }

        /// <summary>
        ///     Sets <see cref="EventsFromDispatcher"/> to true.
        /// </summary>
        internal void SetEventsFromDispatcher()
        {
            EventsFromDispatcher = true;
        }

        /// <summary>
        ///     Helper method to run code from the dispatcher if <see cref="EventsFromDispatcher"/> is set.
        /// </summary>
        /// <param name="action">The action to perform.</param>
        public void DispatchIfNeeded(Action action)
        {
            if (EventsFromDispatcher)
            {
                Dispatcher.InvokeAsync(() =>
                {
                    action.Invoke();
                });
            }
            else
            {
                action.Invoke();
            }
        }
    }
}