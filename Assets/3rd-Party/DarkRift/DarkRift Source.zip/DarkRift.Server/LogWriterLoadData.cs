﻿using System.Collections.Specialized;

namespace DarkRift.Server
{
    public class LogWriterLoadData : PluginBaseLoadData
    {
        public LogWriterLoadData(string name, NameValueCollection settings, DarkRiftInfo serverInfo, DarkRiftThreadHelper threadHelper)
            : base(name, settings, serverInfo, threadHelper)
        {
        }

        internal LogWriterLoadData(string name, DarkRiftServer server, NameValueCollection settings)
            : base(name, server, settings)
        {
        }
    }
}