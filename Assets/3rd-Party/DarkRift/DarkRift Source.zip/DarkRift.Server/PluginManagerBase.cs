﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Base plugin manager for plugin managers handling <see cref="ExtendedPluginBase"/> types.
    /// </summary>
    /// <typeparam name="T">The type of plugin being managed.</typeparam>
    abstract class PluginManagerBase<T> : IDisposable where T : PluginBase
    {
        /// <summary>
        ///     The plugins that have been loaded.
        /// </summary>
        Dictionary<string, T> plugins = new Dictionary<string, T>(StringComparer.OrdinalIgnoreCase);

        /// <summary>
        ///     The DarRiftServer that owns this PluginManagerBase.
        /// </summary>
        protected DarkRiftServer Server { get; }

        /// <summary>
        ///     Creates a new PluginManagerBase.
        /// </summary>
        /// <param name="server">The server that owns this plugin manager.</param>
        internal PluginManagerBase(DarkRiftServer server)
        {
            this.Server = server;
        }
        
        /// <summary>
        ///     Load the plugin given.
        /// </summary>
        /// <param name="name">The name of the plugin instance.</param>
        /// <param name="type">The plugin type to load.</param>
        /// <param name="pluginLoadData">The data for this plugin.</param>
        /// <param name="backupLoadData">The data for this plugin if the first fails.</param>
        /// <param name="createResourceDirectory">Whether to create a resource directory or not.</param>
        protected virtual T LoadPlugin(string name, Type type, PluginBaseLoadData pluginLoadData, PluginLoadData backupLoadData, bool createResourceDirectory)
        {
            //Ensure the resource directory is present
            if (createResourceDirectory)
                Server.DataManager.CreateResourceDirectory(type.Name);
            
            T plugin = Server.PluginFactory.Create<T>(type, pluginLoadData);

            plugins.Add(name, plugin);

            return plugin;
        }

        /// <summary>
        ///     Load the plugin given.
        /// </summary>
        /// <param name="name">The name of the plugin instance.</param>
        /// <param name="type">The plugin type to load.</param>
        /// <param name="pluginLoadData">The data for this plugin.</param>
        /// <param name="backupLoadData">The data for this plugin if the first fails.</param>
        /// <param name="createResourceDirectory">Whether to create a resource directory or not.</param>
        protected virtual T LoadPlugin(string name, string type, PluginBaseLoadData pluginLoadData, PluginLoadData backupLoadData, bool createResourceDirectory)
        {
            //Ensure the resource directory is present
            if (createResourceDirectory)
                Server.DataManager.CreateResourceDirectory(type);

            T plugin = Server.PluginFactory.Create<T>(type, pluginLoadData);

            plugins.Add(name, plugin);

            return plugin;
        }

        /// <summary>
        ///     The plugins loaded.
        /// </summary>
        protected IEnumerable<T> GetPlugins()
        {
            if (!Server.Loaded)
                throw new InvalidOperationException("You cannot search for plugins during initialization, use the Loaded event instead.");
            
            return plugins.Values;
        }

        /// <summary>
        ///     Gets a plugin by name.
        /// </summary>
        protected T GetPlugin(string name)
        {
            if (!Server.Loaded)
                throw new InvalidOperationException("You cannot search for plugins during initialization, use the Loaded event instead.");

            return plugins[name];
        }

        /// <summary>
        ///     Searches for the given plugin name.
        /// </summary>
        /// <param name="name">The name of the plugin.</param>
        /// <returns>Whether the plugins was found.</returns>
        protected bool ContainsPlugin(string name)
        {
            return plugins.ContainsKey(name);
        }

        /// <summary>
        ///     Disposes of this PluginManager.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        ///     Disposes of this PluginManager.
        /// </summary>
        /// <param name="disposing">Are we disposing?</param>
        void Dispose(bool disposing)
        {
            foreach (T plugin in plugins.Values)
                plugin.Dispose();
        }
    }
}
