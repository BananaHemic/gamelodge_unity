﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Event arguments for <see cref="Command"/> callbacks.
    /// </summary>
    public sealed class CommandEventArgs : EventArgs
    {
        /// <summary>
        ///     The command being executed.
        /// </summary>
        public Command Command { get; }

        /// <summary>
        ///     The command as typed in by the user.
        /// </summary>
        public string OriginalCommand { get; }

        /// <summary>
        ///     The arguments the command was called with.
        /// </summary>
        public string[] RawArguments { get; }
        
        /// <summary>
        ///     The arguments passed with the command that weren't flags.
        /// </summary>
        public string[] Arguments { get; }

        /// <summary>
        ///     The flags that were passed with the command.
        /// </summary>
        public NameValueCollection Flags { get; }

        /// <summary>
        ///     The log manager to output syntax errors to.
        /// </summary>
        LogManager logManager;

        internal CommandEventArgs(Command command, string originalCommand, string[] rawArguments, string[] arguments, NameValueCollection flags, LogManager logManager)
        {
            this.Command = command;
            this.OriginalCommand = originalCommand;
            this.RawArguments = arguments;
            this.Arguments = arguments;
            this.Flags = flags;
            this.logManager = logManager;
        }
        
        /// <summary>
        ///     Returns whether the arguments contain the specified flag.
        /// </summary>
        /// <param name="name">The name of the flag.</param>
        /// <returns>Whether the flag is present.</returns>
        public bool HasFlag(string name)
        {
            return Flags.AllKeys.Contains(name);
        }
    }
}
