﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Manager for all <see cref="NetworkListener"/> plugins.
    /// </summary>
    internal sealed class NetworkListenerManager : PluginManagerBase<NetworkListener>, INetworkListenerManager
    {
        internal NetworkListenerManager(DarkRiftServer server)
            : base(server)
        {
        }

        /// <summary>
        ///     Loads the plugins found by the plugin factory.
        /// </summary>
        /// <param name="settings">The settings to load plugins with.</param>
        internal void LoadNetworkListeners(ServerSpawnData.ListenersSettings settings)
        {
            foreach (ServerSpawnData.ListenersSettings.NetworkListenerSettings s in settings.NetworkListeners)
            {
                NetworkListenerLoadData loadData = new NetworkListenerLoadData(
                    s.Name,
                    Server,
                    s.Settings,
                    (message, logType, exception) => Server.InternalLogManager.WriteEvent(s.Name, message, logType, exception)
                );

                LoadPlugin(s.Name, s.Type, loadData, null, false);
            }
        }

        /// <summary>
        ///     Load the listener given.
        /// </summary>
        /// <param name="type">The plugin type to load.</param>
        /// <param name="name">The name of the plugins instance.</param>
        /// <param name="settings">The settings for this plugin.</param>
        internal NetworkListener LoadNetworkListener(Type type, string name, NameValueCollection settings)
        {
            NetworkListenerLoadData loadData = new NetworkListenerLoadData(
                type.Name,
                Server,
                settings,
                (message, logType, exception) => Server.InternalLogManager.WriteEvent(type.Name, message, logType, exception)
            );

            return LoadPlugin(name, type, loadData, null, false);
        }

        /// <summary>
        ///     Starts all <see cref="NetworkListener">NetworkListeners</see> listening.
        /// </summary>
        internal void StartListening()
        {
            foreach (NetworkListener listener in GetPlugins())
                listener.StartListening();
        }

        /// <inheritdoc/>
        public NetworkListener this[string name]
        {
            get
            {
                return GetPlugin(name);
            }
        }

        /// <inheritdoc/>
        public NetworkListener GetNetworkListenerByName(string name)
        {
            return this[name];
        }

        /// <inheritdoc/>
        public T[] GetNetworkListenersByType<T>() where T : NetworkListener
        {
            return GetPlugins().Where((x) => x is T).Cast<T>().ToArray();
        }

        /// <inheritdoc/>
        public NetworkListener[] GetNetworkListeners()
        {
            return GetPlugins().Where((p) => !p.Hidden).ToArray();
        }

        /// <inheritdoc/>
        public NetworkListener[] GetAllNetworkListeners()
        {
            return GetPlugins().ToArray();
        }
    }
}
