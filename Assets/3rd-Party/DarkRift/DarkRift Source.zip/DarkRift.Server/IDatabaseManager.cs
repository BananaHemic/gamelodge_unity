﻿namespace DarkRift.Server
{
    /// <summary>
    ///     Manages the connection strings used by server plugins.
    /// </summary>
    public interface IDatabaseManager
    {
        /// <summary>
        ///     Gets a connection string defined in the configuration file. 
        /// </summary>
        /// <param name="providerName">The name of the connection string.</param>
        /// <returns>
        ///     The connection string.
        /// </returns>
        string this[string providerName] { get; }

        /// <summary>
        ///     Gets a connection string defined in the configuration file. 
        /// </summary>
        /// <param name="providerName">The name of the connection string.</param>
        /// <returns>
        ///     The connection string.
        /// </returns>
        string GetConnectionString(string providerName);
    }
}