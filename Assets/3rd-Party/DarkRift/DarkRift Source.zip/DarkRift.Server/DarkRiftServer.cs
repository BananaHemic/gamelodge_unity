﻿using System;
using DarkRift.Dispatching;
using System.Threading;
using DarkRift.Server.Plugins.Chat;
using System.Collections.Specialized;

namespace DarkRift.Server
{
    /// <summary>
    ///     The main server class.
    /// </summary>
    public sealed class DarkRiftServer : IDisposable
    {
        /// <summary>
        ///     The manager for logs.
        /// </summary>
        internal LogManager InternalLogManager { get; }

#if PRO
        /// <summary>
        ///     The manager for logs.
        /// </summary>
        /// <remarks>
        ///     Pro only.
        /// </remarks>
        public ILogManager LogManager => InternalLogManager;
#endif

        /// <summary>
        ///     The factory for plugins.
        /// </summary>
        internal PluginFactory PluginFactory { get; }

        /// <summary>
        ///     The client manager handling all clients on this server.
        /// </summary>
        internal ClientManager InternalClientManager { get; }

        /// <summary>
        ///     The client manager handling all clients on this server.
        /// </summary>
        public IClientManager ClientManager => InternalClientManager;

        /// <summary>
        ///     The manager for all plugins.
        /// </summary>
        public IPluginManager PluginManager => InternalPluginManager;

        /// <summary>
        ///     The manager for all listeners.
        /// </summary>
        public INetworkListenerManager NetworkListenerManager => InternalNetworkListenerManager;

        /// <summary>
        ///     The handler for all commands issued from the user.
        /// </summary>
        internal CommandEngine CommandEngine { get; }

        /// <summary>
        ///     The manager for databases.
        /// </summary>
        public IDatabaseManager DatabaseManager { get; }

        /// <summary>
        ///     The server's dispatcher.
        /// </summary>
        public IDispatcher Dispatcher => dispatcher;

        /// <summary>
        ///     The dispatcher's wait handle.
        /// </summary>
        public WaitHandle DispatcherWaitHandle => dispatcher.WaitHandle;

        /// <summary>
        ///     Whether events are executed through the dispatcher or not.
        /// </summary>
        public bool EventsFromDispatcher => ThreadHelper.EventsFromDispatcher;

        /// <summary>
        ///     The thread helper for use with events.
        /// </summary>
        public DarkRiftThreadHelper ThreadHelper { get; }
        
        /// <summary>
        ///     Information about this server.
        /// </summary>
        public DarkRiftInfo ServerInfo { get; } = new DarkRiftInfo(DateTime.Now);

#if PRO
        /// <summary>
        ///     Helper plugin for filtering bad words out of text.
        /// </summary>
        /// <remarks>
        ///     Pro only.
        /// </remarks>
        public IBadWordFilter BadWordFilter => PluginManager.GetPluginByType<BadWordFilter>();
#endif

        /// <summary>
        ///     The manager for server data.
        /// </summary>
        internal DataManager DataManager { get; }
        
        /// <summary>
        ///     Whether this server has been loaded yet.
        /// </summary>
        public bool Loaded { get; set; }

        /// <summary>
        ///     The dispatcher for the server.
        /// </summary>
        readonly Dispatcher dispatcher;
        
        /// <summary>
        ///     The server plugin manager.
        /// </summary>
        internal readonly PluginManager InternalPluginManager;

        /// <summary>
        ///     The server listener manager.
        /// </summary>
        internal readonly NetworkListenerManager InternalNetworkListenerManager;

        /// <summary>
        ///     Creates a new server given spawn details.
        /// </summary>
        /// <param name="spawnData">The details of how to start the server.</param>
        public DarkRiftServer(ServerSpawnData spawnData)
        {
            //Initialize log manager and set initial writer
            InternalLogManager = new LogManager(this);

            //Initialize data manager
            DataManager = new DataManager(this, spawnData.Data);

            //Initialize object cache before we shoot ourselves in the foot
            bool initializedCache = ObjectCache.Initialize(new ObjectCacheSettings(
                spawnData.Cache.MaxCachedWriters,
                spawnData.Cache.MaxCachedReaders,
                spawnData.Cache.MaxCachedMessages,
                spawnData.Cache.MaxCachedSocketAsyncEventArgs,
                spawnData.Cache.MaxActionDispatcherTasks
            ));
            
            //Set before loading plugins so plugins override this setting
            dispatcher = new Dispatcher(false);
            ThreadHelper = new DarkRiftThreadHelper(spawnData.EventsFromDispatcher, dispatcher);

            //Load plugin factory so we can load log writers
            PluginFactory = new PluginFactory(this);
            PluginFactory.AddFromSettings(spawnData.PluginSearch);
            PluginFactory.AddTypes(
                new Type[]
                {
                    typeof(Plugins.LogWriters.ConsoleWriter),
                    typeof(Plugins.LogWriters.DebugWriter),
                    typeof(Plugins.LogWriters.FileWriter)
                }
            );
            PluginFactory.AddTypes(
                new Type[]
                {
                    typeof(Plugins.Commands.HelpCommand),
                    typeof(Plugins.Commands.PluginController),
                    typeof(Plugins.Commands.Sniffer),
                    typeof(Plugins.Commands.DemoCommand),
                    typeof(Plugins.Commands.MessageCommand),
                    typeof(Plugins.Commands.MockCommand),
                    typeof(Plugins.Commands.DebugCommand),
                    typeof(Plugins.Commands.ClientCommand)
                }
            );
#if PRO
            PluginFactory.AddTypes(
                new Type[]
                {
                    typeof(Plugins.Chat.BadWordFilter)
                }
            );
#endif

            //Fix network listeners in
            PluginFactory.AddTypes(
                new Type[]
                {
                    typeof(Plugins.Listeners.Bichannel.BichannelListener),
                    typeof(Plugins.Listeners.Bichannel.CompatibilityBichannelListener)
                }
            );

            //Load log writers from plugin factory
            InternalLogManager.Clear();
            InternalLogManager.LoadWriters(spawnData.Logging);

            //Write system details to logs
            InternalLogManager.WriteEvent(
                nameof(DarkRiftServer),
                $"System Details:\n\tOS: {Environment.OSVersion}\n\tCLS Version: {Environment.Version}\n\tDarkRift: {ServerInfo.Version} - {ServerInfo.Type}",
                LogType.Trace
            );

            //Write whether the cache was initialized
            if (!initializedCache)
                InternalLogManager.WriteEvent(nameof(DarkRiftServer), "Cache already initialized, cannot update settings.", LogType.Trace);


            //Load later stage things
            InternalClientManager = new ClientManager(this, spawnData.Server);

            DatabaseManager = new DatabaseManager(spawnData.Databases);
            
            InternalPluginManager = new PluginManager(this);
            InternalPluginManager.LoadPlugins(spawnData.Plugins);       //Problems loading plugins if above aren't already set!
            
            //Load listeners
            InternalNetworkListenerManager = new NetworkListenerManager(this);
            InternalNetworkListenerManager.LoadNetworkListeners(spawnData.Listeners);

            //Load default if no other listeners are present
            if (spawnData.Listeners.NetworkListeners.Count == 0)
            {
                NameValueCollection listenerSettings = new NameValueCollection()
                {
                    { "address", spawnData.Server.Address.ToString() },
                    { "port", spawnData.Server.Port.ToString() },
                    { "ipVersion", spawnData.Server.IPVersion.ToString() }
                };

                if (spawnData.Server.UseFallbackNetworking)
                {
                    InternalNetworkListenerManager.LoadNetworkListener(
                        typeof(Plugins.Listeners.Bichannel.CompatibilityBichannelListener),
                        "Default",
                        listenerSettings
                    );
                }
                else
                {
                    InternalNetworkListenerManager.LoadNetworkListener(
                        typeof(Plugins.Listeners.Bichannel.BichannelListener),
                        "Default",
                        listenerSettings
                    );
                }
            }

            CommandEngine = new CommandEngine(this);

            //Inform plugins we have loaded
            Loaded = true;
            InternalPluginManager.Loaded();
        }

        /// <summary>
        ///     Starts the server.
        /// </summary>
        public void Start()
        {
            try
            {
                InternalNetworkListenerManager.StartListening();
            }
            catch (Exception e)
            {
                InternalLogManager.WriteEvent(nameof(DarkRiftServer), "A listener threw an exception while starting, the server can't be started.", LogType.Fatal, e);
                return;
            }
        }

        /// <summary>
        ///     Executes all tasks waiting in the dispatcher.
        /// </summary>
        /// <remarks>
        ///     This must be invoked from the same thread that constructs the server since this is deemed the 'main' thread.
        /// </remarks>
        public void ExecuteDispatcherTasks()
        {
            dispatcher.ExecuteDispatcherTasks();
        }

        /// <summary>
        ///     Executes a given command on the server.
        /// </summary>
        /// <param name="command">The command to execute.</param>
        public void ExecuteCommand(string command)
        {
            if (command != "")
                CommandEngine.HandleCommand(command);
        }

#if PRO
        /// <summary>
        ///     Creates a new timer that will invoke the callback a single time.
        /// </summary>
        /// <param name="delay">The delay in milliseconds before invoking the callback.</param>
        /// <param name="callback">The callback to invoke.</param>
        /// <returns>The new timer.</returns>
        public Timer CreateOneShotTimer(int delay, Action<Timer> callback)
        {
            return new Timer(ThreadHelper, delay, callback);
        }

        /// <summary>
        ///     Creates a new timer that will invoke the callback repeatedly until stopped.
        /// </summary>
        /// <param name="initialDelay">The delay in milliseconds before invoking the callback the first time.</param>
        /// <param name="repetitionPeriod">The delay in milliseconds between future invocations.</param>
        /// <param name="callback">The callback to invoke.</param>
        /// <returns>The new timer.</returns>
        public Timer CreateTimer(int initialDelay, int repetitionPeriod, Action<Timer> callback)
        {
            return new Timer(ThreadHelper, initialDelay, repetitionPeriod, callback);
        }
#endif

        /// <summary>
        ///     Forces the server to invoke events through the dispatcher.
        /// </summary>
        internal void MakeThreadSafe()
        {
            ThreadHelper.SetEventsFromDispatcher();

            InternalLogManager.WriteEvent(nameof(DarkRiftServer), $"Switched into thread safe mode. Expect lower performance!", LogType.Trace);
        }

        /// <summary>
        ///     Disposes of the server.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        void Dispose(bool disposing)
        {
            if (disposing)
            {
                InternalClientManager.Dispose();
                InternalPluginManager.Dispose();
                InternalNetworkListenerManager.Dispose();
                DataManager.Dispose();
                InternalLogManager.Dispose();
                dispatcher.Dispose();
            }
        }
    }
}
