﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
#if PRO
    /// <summary>
    ///     Event arguments for the <see cref="Client.StrikeOccured"/> event.
    /// </summary>
    public sealed class StrikeEventArgs : EventArgs
    {
        /// <summary>
        ///     The reason the strike was given.
        /// </summary>
        public StrikeReason Reason { get; private set; }

        /// <summary>
        ///     The message supplied with the strike.
        /// </summary>
        /// <remarks>
        ///     May be null in the case that no message is supplied.
        /// </remarks>
        public string Message { get; private set; }

        /// <summary>
        ///     Has this strike been forgiven by a plugin?
        /// </summary>
        public bool Forgiven { get; private set; }

        internal StrikeEventArgs(StrikeReason reason, string message)
        {
            this.Reason = reason;
        }

        /// <summary>
        ///     Forgives the client of this strike so it will not count against them.
        /// </summary>
        public void Forgive()
        {
            Forgiven = true;
        }
    }
#endif
}
