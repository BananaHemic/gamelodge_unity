﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml.Linq;

namespace DarkRift.Server
{
    /// <summary>
    ///     Handles the persistent data for a DarkRift instance.
    /// </summary>
    sealed class DataManager : IDisposable
    {
        /// <summary>
        ///     The name of the plugins DB file.
        /// </summary>
        readonly string pluginsFileName;

        /// <summary>
        ///     The name of the plugins DB mutex.
        /// </summary>
        readonly Mutex pluginsFileMutex;

        /// <summary>
        ///     The server this belongs to.
        /// </summary>
        readonly DarkRiftServer server;

        /// <summary>
        ///     The directory for storing data in.
        /// </summary>
        readonly string dataDirectory;

        internal DataManager(DarkRiftServer server, ServerSpawnData.DataSettings settings)
        {
            this.server = server;
            this.dataDirectory = settings.Directory;

            DirectoryInfo directory = Directory.CreateDirectory(dataDirectory);
            directory.Attributes |= FileAttributes.Hidden;

            pluginsFileName = Path.Combine(dataDirectory, "Plugins.xml");
            pluginsFileMutex = new Mutex(false, pluginsFileName.GetHashCode() + " lock");
            CreatePluginsTable();
        }

        #region Resouce Folders
        
        /// <summary>
        ///     Gets the location of a plugins resources directory.
        /// </summary>
        /// <param name="pluginName">The name of the plugin.</param>
        /// <returns>The path to the resource directory.</returns>
        internal string GetResourceDirectory(string pluginName) => Path.Combine(dataDirectory, pluginName);

        /// <summary>
        ///     Creates the resource directory for a plugin if it doesn't exist.
        /// </summary>
        /// <param name="pluginName">The name of the plugin.</param>
        internal void CreateResourceDirectory(string pluginName)
        {
            Directory.CreateDirectory(GetResourceDirectory(pluginName));
        }

        /// <summary>
        ///     Deletes the resource directory for a plugin.
        /// </summary>
        /// <param name="pluginName">The name of the plugin.</param>
        internal void DeleteResourceDirectory(string pluginName)
        {
            Directory.Delete(GetResourceDirectory(pluginName), true);
        }

        #endregion

        #region Plugin Records

        /// <summary>
        ///     Atomically reads a plugin record and updates the fields as specified or
        ///     creates a new record if not present.
        /// </summary>
        /// <param name="name">The plugin to read and set.</param>
        /// <param name="version">The version to update the record to.</param>
        internal PluginRecord ReadAndSetPluginRecord(string name, Version version)
        {
            try
            {
                pluginsFileMutex.WaitOne();

                XDocument doc = XDocument.Load(pluginsFileName);

                XElement element = doc.Root
                    .Elements()
                    .FirstOrDefault(x => x.Attribute("name").Value == name);

                //If not there, build it
                PluginRecord record;
                if (element == null)
                {
                    element = new XElement("plugin");

                    var idAttribute = doc.Root.Attribute("nextID");
                    uint id = uint.Parse(idAttribute.Value);
                    idAttribute.SetValue(id + 1);

                    element.SetAttributeValue("id", id);
                    element.SetAttributeValue("name", name);

                    doc.Root.Add(element);

                    record = null;
                }
                else
                {
                    record = new PluginRecord(
                        uint.Parse(element.Attribute("id").Value),
                        name,
                        new Version(element.Attribute("version").Value)
                    );
                }

                element.SetAttributeValue("version", version);

                doc.Save(pluginsFileName);

                return record;
            }
            finally
            {
                pluginsFileMutex.ReleaseMutex();
            }
        }

        /// <summary>
        ///     Reads a record from the plugin metadata.
        /// </summary>
        /// <param name="name">The name fo the plugin.</param>
        /// <returns>The plugin record.</returns>
        internal PluginRecord ReadPluginRecord(string name)
        {
            XDocument doc;
            try
            {
                pluginsFileMutex.WaitOne();

                doc = XDocument.Load(pluginsFileName);
            }
            finally
            {
                pluginsFileMutex.ReleaseMutex();
            }

            var element = doc.Root
                    .Elements()
                    .FirstOrDefault(x => x.Attribute("name").Value == name);

            if (element == null)
                return null;

            return new PluginRecord(
                uint.Parse(element.Attribute("id").Value),
                name,
                new Version(element.Attribute("version").Value)
            );
        }

        /// <summary>
        ///     Returns all records in the plugins table.
        /// </summary>
        /// <returns>The records stored.</returns>
        internal IEnumerable<PluginRecord> ReadAllPluginRecords()
        {
            XDocument doc;
            try
            {
                pluginsFileMutex.WaitOne();

                doc = XDocument.Load(pluginsFileName);
            }
            finally
            {
                pluginsFileMutex.ReleaseMutex();
            }

            return doc.Root
                .Elements()
                .Select(
                    (e) =>
                        new PluginRecord(
                            uint.Parse(e.Attribute("id").Value),
                            e.Attribute("name").Value,
                            new Version(e.Attribute("version").Value)
                        )
                );
        }

        /// <summary>
        ///     Deletes a record from the plugin table.
        /// </summary>
        /// <param name="name">The plugin to delete.</param>
        internal void DeletePluginRecord(string name)
        {
            try
            {
                pluginsFileMutex.WaitOne();

                XDocument doc = XDocument.Load(pluginsFileName);
                doc.Root
                    .Elements()
                    .Single(e => e.Attribute("name").Value == name)
                    .Remove();

                doc.Save(pluginsFileName);
            }
            finally
            {
                pluginsFileMutex.ReleaseMutex();
            }
        }

        /// <summary>
        ///     Creates a new table for storing plugin metadata.
        /// </summary>
        void CreatePluginsTable()
        {
            try
            {
                pluginsFileMutex.WaitOne();

                if (!File.Exists(pluginsFileName))
                {
                    XDocument doc = new XDocument();
                    if (doc.Root == null)
                        doc.Add(new XElement("plugins", new XAttribute("nextID", 0)));

                    doc.Save(pluginsFileName);
                }
            }
            finally
            {
                pluginsFileMutex.ReleaseMutex();
            }
        }

        #endregion

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    pluginsFileMutex.Close();
                }
                disposedValue = true;
            }
        }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}
