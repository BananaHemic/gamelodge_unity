﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;

namespace DarkRift.Server
{
    /// <summary>
    ///     Base plugin manager for plugin managers handling <see cref="ExtendedPluginBase"/> types.
    /// </summary>
    /// <typeparam name="T">The type of plugin being managed.</typeparam>
    abstract class ExtendedPluginManagerBase<T> : PluginManagerBase<T>  where T : ExtendedPluginBase
    {   
        /// <summary>
        ///     Creates a new ExtendedPluginManagerBase.
        /// </summary>
        /// <param name="server">The server that owns this plugin manager.</param>
        internal ExtendedPluginManagerBase(DarkRiftServer server)
            : base(server)
        {
        }

        /// <summary>
        ///     Load the plugin given.
        /// </summary>
        /// <param name="name">The name of the plugin instance.</param>
        /// <param name="type">The plugin type to load.</param>
        /// <param name="pluginLoadData">The data for this plugin.</param>
        /// <param name="backupLoadData">The data for this plugin if the first fails.</param>
        /// <param name="createResourceDirectory">Whether to create a resource directory or not.</param>
        protected override T LoadPlugin(string name, Type type, PluginBaseLoadData pluginLoadData, PluginLoadData backupLoadData, bool createResourceDirectory)
        {
            T plugin = base.LoadPlugin(name, type, pluginLoadData, backupLoadData, createResourceDirectory);

            HandleThreadSafe(plugin);

            HandleInstallUpgrade(plugin);

            return plugin;
        }

        /// <summary>
        ///     Load the plugin given.
        /// </summary>
        /// <param name="name">The name of the plugin instance.</param>
        /// <param name="type">The plugin type to load.</param>
        /// <param name="pluginLoadData">The data for this plugin.</param>
        /// <param name="backupLoadData">The data for this plugin if the first fails.</param>
        /// <param name="createResourceDirectory">Whether to create a resource directory or not.</param>
        protected override T LoadPlugin(string name, string type, PluginBaseLoadData pluginLoadData, PluginLoadData backupLoadData, bool createResourceDirectory)
        {
            T plugin = base.LoadPlugin(name, type, pluginLoadData, backupLoadData, createResourceDirectory);

            HandleThreadSafe(plugin);

            HandleInstallUpgrade(plugin);

            return plugin;
        }

        /// <summary>
        ///     Make server threadsafe if necessary
        /// </summary>
        /// <param name="plugin">The plugin to check.</param>
        void HandleThreadSafe(T plugin)
        {
            if (!plugin.ThreadSafe)
            {
                Server.InternalLogManager.WriteEvent(nameof(ExtendedPluginManagerBase<T>), $"Plugin '{plugin.Name}' has requested that DarkRift operates in thread safe mode.", LogType.Trace);
                Server.MakeThreadSafe();
            }
        }

        /// <summary>
        ///     Install/upgrade the loaded plugin.
        /// </summary>
        /// <param name="plugin">The plugin to check.</param>
        void HandleInstallUpgrade(T plugin)
        {
            PluginRecord oldRecord = Server.DataManager.ReadAndSetPluginRecord(plugin.Name, plugin.Version);

            if (oldRecord == null)
            {
                plugin.Install(new InstallEventArgs());

                if (!plugin.Hidden)
                    Server.InternalLogManager.WriteEvent(nameof(ExtendedPluginManagerBase<T>), $"Installed plugin {plugin.Name} version {plugin.Version}", LogType.Info);
            }
            else if (oldRecord.Version == plugin.Version)
            {
                if (!plugin.Hidden)
                    Server.InternalLogManager.WriteEvent(nameof(ExtendedPluginManagerBase<T>), $"Loaded plugin {plugin.Name} version {plugin.Version}", LogType.Info);
            }
            else
            {
                plugin.Upgrade(new UpgradeEventArgs(oldRecord.Version));

                if (!plugin.Hidden)
                    Server.InternalLogManager.WriteEvent(nameof(ExtendedPluginManagerBase<T>), $"Upgraded plugin {plugin.Name} version {plugin.Version} from version {oldRecord.Version}", LogType.Info);
            }
        }

        /// <inheritdoc/>
        public Version GetInstalledVersion(string pluginName)
        {
            return Server.DataManager
                         .ReadPluginRecord(pluginName)
                        ?.Version;
        }

        /// <summary>
        ///     Uninstalls a plugin by name, it cannot be currently operating.
        /// </summary>
        /// <param name="name">The name of the plugin to uninstall.</param>
        internal void Uninstall(string name)
        {
            if (!ContainsPlugin(name))
            {
                Server.InternalLogManager.WriteEvent(nameof(ExtendedPluginManagerBase<T>), $"Uninstalling plugin {name} from the server.", LogType.Trace);

                Server.DataManager.DeletePluginRecord(name);

                Server.DataManager.DeleteResourceDirectory(name);
            }
            else
            {
                throw new InvalidOperationException(ErrorStrings.PLUGIN_STILL_LOADED_UNINSTALL);
            }
        }

        /// <summary>
        ///     Invokes the Loaded event on all plugins.
        /// </summary>
        /// <remarks>
        ///     <see cref="DarkRiftServer.Loaded"/> must be true when this is invoked.
        /// </remarks>
        internal void Loaded()
        {
            foreach (T plugin in GetPlugins())
                plugin.Loaded(new LoadedEventArgs());
        }
    }
}
