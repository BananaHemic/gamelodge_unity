# Databases Element
The `<databases>` element provides a central place to store database connection strings for the server.

## Attributes
There are no attributes for this element.

## Child Elements
- database
