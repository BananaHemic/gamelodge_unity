# Logging Element
`<logging>` element is used to specify a logging settings for the server.
      
## Attributes
There are no attributes for this element.

## Child Elements</title>
- logWriters
