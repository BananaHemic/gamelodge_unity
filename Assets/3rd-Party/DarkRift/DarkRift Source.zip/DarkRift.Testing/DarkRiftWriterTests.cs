﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using DarkRift.Dispatching;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DarkRift.Testing
{
    [TestClass]
    public class DarkRiftWriterTests
    {
        DarkRiftWriter writer;

        [TestInitialize]
        public void Initialize()
        {
            ObjectCache.Initialize(ObjectCacheSettings.DontUseCache);
            writer = DarkRiftWriter.Create();
        }

        [TestMethod]
        public void WriteByteTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write((byte)5);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 5 }, writer.Data);
            Assert.AreEqual(1, writer.Position);
            Assert.AreEqual(1, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteCharTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write('A');

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0, 0, 0, 2, 65, 0 }, writer.Data);
            Assert.AreEqual(6, writer.Position);
            Assert.AreEqual(6, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteBooleanTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write(true);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 1 }, writer.Data);
            Assert.AreEqual(1, writer.Position);
            Assert.AreEqual(1, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteDoubleTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write(0.75d);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0x3f, 0xE8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, writer.Data);
            Assert.AreEqual(8, writer.Position);
            Assert.AreEqual(8, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteInt16Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write((short)-5982);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0xE8, 0xA2 }, writer.Data);
            Assert.AreEqual(2, writer.Position);
            Assert.AreEqual(2, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteInt32Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write(589574236);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0x23, 0x24, 0x30, 0x5C }, writer.Data);
            Assert.AreEqual(4, writer.Position);
            Assert.AreEqual(4, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteInt64Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write(5895742365555578888);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0x51, 0xD1, 0xE2, 0x71, 0xCA, 0x29, 0x58, 0x08 }, writer.Data);
            Assert.AreEqual(8, writer.Position);
            Assert.AreEqual(8, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteSByteTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write((sbyte)-45);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0xD3 }, writer.Data);
            Assert.AreEqual(1, writer.Position);
            Assert.AreEqual(1, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteFloatTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write(0.75f);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0x3f, 0x40, 0x00, 0x00 }, writer.Data);
            Assert.AreEqual(4, writer.Position);
            Assert.AreEqual(4, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteUInt16Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write((ushort)59554);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0xE8, 0xA2 }, writer.Data);
            Assert.AreEqual(2, writer.Position);
            Assert.AreEqual(2, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteUInt32Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write((uint)589574236);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0x23, 0x24, 0x30, 0x5C }, writer.Data);
            Assert.AreEqual(4, writer.Position);
            Assert.AreEqual(4, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteUInt64Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write((ulong)5895742365555578888);

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0x51, 0xD1, 0xE2, 0x71, 0xCA, 0x29, 0x58, 0x08 }, writer.Data);
            Assert.AreEqual(8, writer.Position);
            Assert.AreEqual(8, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteStringTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write("ABC");

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0, 0, 0, 6, 65, 0, 66, 0, 67, 0 }, writer.Data);
            Assert.AreEqual(10, writer.Position);
            Assert.AreEqual(10, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void WriteBooleansTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            writer.Write(new bool[] { true, true, false, false, true, false, true, false, true });

            AssertExtensions.AreEqualAndNotShorter(new byte[] { 0, 0, 0, 9, 0b11001010, 0b10000000 }, writer.Data);
            Assert.AreEqual(6, writer.Position);
            Assert.AreEqual(6, writer.Length);

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }
    }
}
