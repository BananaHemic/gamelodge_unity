﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DarkRift.Testing
{
    [TestClass]
    public class DarkRiftReaderTests
    {
        [TestInitialize]
        public void Initialize()
        {
            ObjectCache.Initialize(ObjectCacheSettings.DontUseCache);
        }

        [TestMethod]
        public void ReadByteTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 5 }, 0, 1);

            Assert.AreEqual((byte)5, reader.ReadByte());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadCharTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0, 0, 0, 2, 65, 0 }, 0, 6);

            Assert.AreEqual('A', reader.ReadChar());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadBooleanTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 1 }, 0, 1);

            Assert.AreEqual(true, reader.ReadBoolean());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadDoubleTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0x3f, 0xE8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }, 0, 10);

            Assert.AreEqual(0.75d, reader.ReadDouble());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }
        
        [TestMethod]
        public void ReadInt16Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0xE8, 0xA2 }, 0, 2);

            Assert.AreEqual((short)-5982, reader.ReadInt16());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadInt32Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0x23, 0x24, 0x30, 0x5C }, 0, 4);

            Assert.AreEqual(589574236, reader.ReadInt32());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadInt64Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0x51, 0xD1, 0xE2, 0x71, 0xCA, 0x29, 0x58, 0x08 }, 0, 8);

            Assert.AreEqual(5895742365555578888L, reader.ReadInt64());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadSByteTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0xD3 }, 0, 1);

            Assert.AreEqual((sbyte)-45, reader.ReadSByte());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadSingleTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0x3f, 0x40, 0x00, 0x00 }, 0, 4);

            Assert.AreEqual(0.75f, reader.ReadSingle());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadUInt16Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0xE8, 0xA2 }, 0, 2);

            Assert.AreEqual((ushort)59554, reader.ReadUInt16());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadUInt32Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0x23, 0x24, 0x30, 0x5C }, 0, 4);

            Assert.AreEqual((uint)589574236, reader.ReadUInt32());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadUInt64Test()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0x51, 0xD1, 0xE2, 0x71, 0xCA, 0x29, 0x58, 0x08 }, 0, 8);

            Assert.AreEqual((ulong)5895742365555578888, reader.ReadUInt64());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadStringTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0, 0, 0, 6, 65, 0, 66, 0, 67, 0 }, 0, 10);

            Assert.AreEqual("ABC", reader.ReadString());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }

        [TestMethod]
        public void ReadBooleansTest()
        {
            long startingMemory = GC.GetTotalMemory(false);

            DarkRiftReader reader = DarkRiftReader.Create(new byte[] { 0, 0, 0, 9, 0b11001010, 0b10000000 }, 0, 6);

            AssertExtensions.AreEqualAndSameLength(new bool[] { true, true, false, false, true, false, true, false, true }, reader.ReadBooleans());

            //GC check
            Assert.AreEqual(startingMemory, GC.GetTotalMemory(false));
        }
    }
}
