﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace DarkRift.Client
{
    /// <summary>
    ///     The client for DarkRift connections.
    /// </summary>
    public class DarkRiftClient : IDisposable
    {
        /// <summary>
        ///     Event fired when a message is received.
        /// </summary>
        public event EventHandler<MessageReceivedEventArgs> MessageReceived;

        /// <summary>
        ///     Event fired when the client becomes disconnected.
        /// </summary>
        public event EventHandler<DisconnectedEventArgs> Disconnected;

        /// <summary>
        ///     The ID the client has been assigned.
        /// </summary>
        public ushort ID { get; private set; }

        /// <summary>
        ///     The state of the connection.
        /// </summary>
        public ConnectionState ConnectionState => Connection?.ConnectionState ?? ConnectionState.Disconnected;

        /// <summary>
        ///     Returns whether or not this client is connected to the server.
        /// </summary>
        [Obsolete("Use DarkRiftClient.ConnectionState instead.")]
        public bool Connected => Connection == null ? false : Connection.ConnectionState == ConnectionState.Connected;

        /// <summary>
        ///     The endpoints of the connection.
        /// </summary>
        public IEnumerable<IPEndPoint> RemoteEndPoints => Connection?.RemoteEndPoints ?? new IPEndPoint[0];

        /// <summary>
        ///     The remote end point of the connection.
        /// </summary>
        [Obsolete("Use DarkRiftClient.GetRemoteEndPoint(\"TCP\") instead.")]
        public IPEndPoint RemoteEndPoint => Connection?.GetRemoteEndPoint("TCP");

        /// <summary>
        ///     Delegate type for handling the completion of an asynchronous connect.
        /// </summary>
        /// <param name="e">The exception that occured, if any.</param>
        public delegate void ConnectCompleteHandler(Exception e);

        /// <summary>
        ///     The connection to the remote server.
        /// </summary>
        public NetworkClientConnection Connection { get; private set; }

        /// <summary>
        ///     Mutex that is triggered once the connection is completely setup.
        /// </summary>
        ManualResetEvent setupMutex = new ManualResetEvent(false);

        /// <summary>
        ///     Creates a new DarkRift client object with specified cache settings.
        /// </summary>
        /// <param name="maxCachedWriters">The maximum number of DarkRiftWriters to cache per thread.</param>
        /// <param name="maxCachedReaders">The maximum number of DarkRiftReaders to cache per thread.</param>
        /// <param name="maxCachedMessages">The maximum number of Messages to cache per thread.</param>
        /// <param name="maxCachedSocketAsyncEventArgs">The maximum number of SocketAsyncEventArgs to cache per thread.</param>
        /// <param name="maxActionDispatcherTasks">The maximum number of ActionDispatcherTasks to cache per thread.</param>
        public DarkRiftClient(int maxCachedWriters = 2, int maxCachedReaders = 2, int maxCachedMessages = 4, int maxCachedSocketAsyncEventArgs = 32, int maxActionDispatcherTasks = 16)
        {
            ObjectCache.Initialize(new ObjectCacheSettings(maxCachedWriters, maxCachedReaders, maxCachedMessages, maxCachedSocketAsyncEventArgs, maxActionDispatcherTasks));
        }
        
        /// <summary>
        ///     Connects to a remote server using a <see cref="BichannelClientConnection"/>.
        /// </summary>
        /// <param name="ip">The IP address of the server.</param>
        /// <param name="port">The port of the server.</param>
        /// <param name="ipVersion">The IP version to connect using.</param>
        public void Connect(IPAddress ip, int port, IPVersion ipVersion)
        {
            Connect(ip, port, ipVersion, false);
        }

        /// <summary>
        ///     Connects to a remote server using a <see cref="BichannelClientConnection"/>.
        /// </summary>
        /// <param name="ip">The IP address of the server.</param>
        /// <param name="port">The port of the server.</param>
        /// <param name="ipVersion">The IP version to connect using.</param>
        /// <param name="noDelay">Whether to disable Nagel's algorithm or not.</param>
        public void Connect(IPAddress ip, int port, IPVersion ipVersion, bool noDelay)
        {
            Connect(new BichannelClientConnection(ipVersion, ip, port, noDelay));
        }

        /// <summary>
        ///     Connects the client using the given connection.
        /// </summary>
        /// <param name="connection">The connection to use to connect to the server.</param>
        public void Connect(NetworkClientConnection connection)
        {
            setupMutex.Reset();

            if (this.Connection != null)
                this.Connection.Dispose();

            this.Connection = connection;
            connection.MessageReceived = MessageReceivedHandler;
            connection.Disconnected = DisconnectedHandler;

            connection.Connect();

            setupMutex.WaitOne();
        }

        /// <summary>
        ///     Connects to a remote server in the background using a <see cref="BichannelClientConnection"/>.
        /// </summary>
        /// <param name="ip">The IP address of the server.</param>
        /// <param name="port">The port of the server.</param>
        /// <param name="ipVersion">The IP version to connect using.</param>
        /// <param name="callback">The callback to invoke one the connection attempt has finished.</param>
        public void ConnectInBackground(IPAddress ip, int port, IPVersion ipVersion, ConnectCompleteHandler callback = null)
        {
            ConnectInBackground(ip, port, ipVersion, false, callback);
        }

        /// <summary>
        ///     Connects to a remote server in the background using a <see cref="BichannelClientConnection"/>.
        /// </summary>
        /// <param name="ip">The IP address of the server.</param>
        /// <param name="port">The port of the server.</param>
        /// <param name="ipVersion">The IP version to connect using.</param>
        /// <param name="callback">The callback to invoke one the connection attempt has finished.</param>
        /// <param name="noDelay">Whether to disable Nagel's algorithm or not.</param>
        public void ConnectInBackground(IPAddress ip, int port, IPVersion ipVersion, bool noDelay, ConnectCompleteHandler callback = null)
        {
            ConnectInBackground(new BichannelClientConnection(ipVersion, ip, port, noDelay), callback);
        }

        /// <summary>
        ///     Connects to a remote server in the background.
        /// </summary>
        /// <param name="connection">The connection to use to connect to the server.</param>
        /// <param name="callback">The callback to invoke one the connection attempt has finished.</param>
        public void ConnectInBackground(NetworkClientConnection connection, ConnectCompleteHandler callback = null)
        {
            new Thread(
                delegate ()
                {
                    try
                    {
                        Connect(connection);
                    }
                    catch (Exception e)
                    {
                        callback?.Invoke(e);
                        return;
                    }

                    callback?.Invoke(null);
                }
            ).Start();
        }

        /// <summary>
        ///     Sends a message to the server.
        /// </summary>
        /// <param name="message">The message to send.</param>
        /// <param name="sendMode">How the message should be sent.</param>
        /// <returns>Whether the send was successful.</returns>
        public bool SendMessage(Message message, SendMode sendMode)
        {
            return Connection.SendMessage(message.ToBuffer(), sendMode);
        }

        /// <summary>
        ///     Gets the endpoint with the given name.
        /// </summary>
        /// <param name="name">The name of the endpoint.</param>
        /// <returns>The end point.</returns>
        public IPEndPoint GetRemoteEndPoint(string name)
        {
            return Connection.GetRemoteEndPoint(name);
        }

        /// <summary>
        ///     Disconnects this client from the server.
        /// </summary>
        /// <returns>Whether the disconnect was successful.</returns>
        public bool Disconnect()
        {
            if (Connection == null)
                return false;

            if (!Connection.Disconnect())
                return false;

            Disconnected?.Invoke(this, new DisconnectedEventArgs(true, SocketError.Disconnecting, null));

            return true;
        }

        /// <summary>
        ///     Callback for when data is received.
        /// </summary>
        /// <param name="buffer">The data recevied.</param>
        /// <param name="sendMode">The SendMode used to send the data.</param>
        void MessageReceivedHandler(MessageBuffer buffer, SendMode sendMode)
        {
            Message message = Message.Create(buffer, true);
            
            if (message.IsCommandMessage)
                HandleCommand(message);
            else
                HandleMessage(message, sendMode);
        }

        /// <summary>
        ///     Handles a command received.
        /// </summary>
        /// <param name="message">The message that was received.</param>
        void HandleCommand(Message message)
        {
            using (DarkRiftReader reader = message.GetReader())
            {
                switch ((CommandCode)message.Tag)
                {
                    case CommandCode.Configure:
                        ID = reader.ReadUInt16();

                        setupMutex.Set();
                        break;
                }
            }
        }

        /// <summary>
        ///     Handles a message received.
        /// </summary>
        /// <param name="message">The message that was received.</param>
        /// <param name="sendMode">The send mode the emssage was received with.</param>
        void HandleMessage(Message message, SendMode sendMode)
        {
            MessageReceivedEventArgs args = new MessageReceivedEventArgs(message, sendMode);

            //Invoke for message received event
            MessageReceived?.Invoke(this, args);
        }

        /// <summary>
        ///     Called when this connection becomes disconnected.
        /// </summary>
        /// <param name="error">The error that caused the disconnection.</param>
        /// <param name="exception">The exception that caused the disconnection.</param>
        void DisconnectedHandler(SocketError error, Exception exception)
        {
            Disconnected?.Invoke(this, new DisconnectedEventArgs(false, error, exception));
        }

        volatile bool disposed = false;
        
        /// <summary>
        ///     Disposes of the DarkRift client object.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        ///     Handles disposing of the DarkRift client object.
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing && !disposed)
            {
                disposed = true;

                if (Connection != null)
                    Connection.Dispose();

                setupMutex.Close();
            }
        }
    }
}
