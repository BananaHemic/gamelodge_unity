﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace DarkRift.Client
{
    /// <summary>
    ///     A connection to a remote server and handles TCP and UDP channels.
    /// </summary>
    public sealed class BichannelClientConnection : NetworkClientConnection, IDisposable
    {
        /// <summary>
        ///     The IP address of the remote client.
        /// </summary>
        public IPEndPoint RemoteTcpEndPoint { get; }

        /// <summary>
        ///     The IP address of the remote client.
        /// </summary>
        public IPEndPoint RemoteUdpEndPoint { get; }
        
        /// <summary>
        ///     Whether Nagel's algorithm should be disabled or not.
        /// </summary>
        public bool NoDelay
        {
            get => tcpSocket.NoDelay;
            set
            {
                tcpSocket.NoDelay = value;
            }
        }

        /// <inheritdoc/>
        public override IEnumerable<IPEndPoint> RemoteEndPoints => new IPEndPoint[] { RemoteTcpEndPoint, RemoteUdpEndPoint };

        /// <inheritdoc/>
        public override ConnectionState ConnectionState => connectionState;

        /// <summary>
        ///     Backing for <see cref="ConnectionState"/>.
        /// </summary>
        ConnectionState connectionState;

        /// <summary>
        ///     The socket used in TCP communication.
        /// </summary>
        readonly Socket tcpSocket;

        /// <summary>
        ///     The socket used in UDP communication.
        /// </summary>
        readonly Socket udpSocket;

        /// <summary>
        ///     Creates a new bichannel client.
        /// </summary>
        /// <param name="ipVersion">The IP version to connect via.</param>
        /// <param name="ipAddress">The IP address of the server.</param>
        /// <param name="port">The port the server is listening on.</param>
        /// <param name="noDelay">Whether to disable Nagle's algorithm or not.</param>
        public BichannelClientConnection(IPVersion ipVersion, IPAddress ipAddress, int port, bool noDelay)
            : base()
        {
            AddressFamily addressFamily = ipVersion == IPVersion.IPv6 ? AddressFamily.InterNetworkV6 : AddressFamily.InterNetwork;

            RemoteTcpEndPoint = new IPEndPoint(ipAddress, port);
            RemoteUdpEndPoint = new IPEndPoint(ipAddress, port);

            tcpSocket = new Socket(addressFamily, SocketType.Stream, ProtocolType.Tcp);
            udpSocket = new Socket(tcpSocket.AddressFamily, SocketType.Dgram, ProtocolType.Udp);
            
            NoDelay = noDelay;
        }

        /// <inheritdoc/>
        public override void Connect()
        {
            connectionState = ConnectionState.Connecting;

            //Connect TCP
            tcpSocket.Connect(RemoteTcpEndPoint);

            //Bind UDP to a free port
            udpSocket.Bind(new IPEndPoint(((IPEndPoint)tcpSocket.LocalEndPoint).Address, 0));
            udpSocket.Connect(RemoteUdpEndPoint);

            //Receive auth token from TCP
            byte[] buffer = new byte[9];
            tcpSocket.ReceiveTimeout = 5000;
            int received = tcpSocket.Receive(buffer);
            tcpSocket.ReceiveTimeout = 0;   //Reset to infinite
            if (received != 9 || buffer[0] != 0)
                throw new SocketException((int)SocketError.ConnectionAborted);
            
            //Transmit token back over UDP to server listening port
            udpSocket.Send(buffer);

            //Receive response from server to initiate the connection
            buffer = new byte[1];
            udpSocket.ReceiveTimeout = 5000;
            udpSocket.Receive(buffer);
            udpSocket.ReceiveTimeout = 0;   //Reset to infinite
            if (buffer[0] != 0)
                throw new SocketException((int)SocketError.ConnectionAborted);

            //Setup the TCP socket to receive a header
            SocketAsyncEventArgs tcpArgs = ObjectCache.GetSocketAsyncEventArgs();
            tcpArgs.BufferList = null;
            tcpArgs.SetBuffer(new byte[4], 0, 4);

            tcpArgs.Completed += TcpHeaderReceiveCompleted;

            bool tcpCompletingAsync = tcpSocket.ReceiveAsync(tcpArgs);
            if (!tcpCompletingAsync)
                TcpHeaderReceiveCompleted(this, tcpArgs);

            //Start receiving UDP packets
            SocketAsyncEventArgs udpArgs = ObjectCache.GetSocketAsyncEventArgs();
            udpArgs.BufferList = null;
            udpArgs.SetBuffer(new byte[ushort.MaxValue], 0, ushort.MaxValue);

            udpArgs.Completed += UdpReceiveCompleted;

            bool udpCompletingAsync = udpSocket.ReceiveAsync(udpArgs);
            if (!udpCompletingAsync)
                UdpReceiveCompleted(this, udpArgs);

            //Mark connected to allow sending
            connectionState = ConnectionState.Connected;
        }

        /// <inheritdoc/>
        public override bool SendMessageReliable(MessageBuffer message)
        {
            if (connectionState == ConnectionState.Disconnected)
                return false;

            byte[] header = new byte[4];
            BigEndianHelper.WriteBytes(header, 0, message.Count);

            SocketAsyncEventArgs args = ObjectCache.GetSocketAsyncEventArgs();

            args.SetBuffer(null, 0, 0);
            args.BufferList = new List<ArraySegment<byte>>()
            {
                new ArraySegment<byte>(header),
                new ArraySegment<byte>(message.Buffer, message.Offset, message.Count)
            };
            args.UserToken = message;

            args.Completed += TcpSendCompleted;

            bool completingAsync = tcpSocket.SendAsync(args);
            if (!completingAsync)
                TcpSendCompleted(this, args);

            return true;
        }

        /// <inheritdoc/>
        public override bool SendMessageUnreliable(MessageBuffer message)
        {
            if (connectionState == ConnectionState.Disconnected)
                return false;

            SocketAsyncEventArgs args = ObjectCache.GetSocketAsyncEventArgs();
            args.BufferList = null;
            args.SetBuffer(message.Buffer, message.Offset, message.Count);
            args.UserToken = message;

            args.Completed += UdpSendCompleted;

            bool completingAsync = udpSocket.SendAsync(args);
            if (!completingAsync)
                UdpSendCompleted(this, args);

            return true;
        }

        /// <inheritdoc/>
        public override bool Disconnect()
        {
            if (connectionState == ConnectionState.Disconnected)
                return false;

            connectionState = ConnectionState.Disconnected;

            tcpSocket.Shutdown(SocketShutdown.Both);

            return true;
        }

        /// <inheritdoc/>
        public override IPEndPoint GetRemoteEndPoint(string name)
        {
            if (name.ToLower() == "tcp")
                return RemoteTcpEndPoint;
            else if (name.ToLower() == "udp")
                return RemoteUdpEndPoint;
            else
                throw new ArgumentException("Endpoint name must either be TCP or UDP");
        }

        /// <summary>
        ///     Called when the 4 byte length header is received by TCP
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TcpHeaderReceiveCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred != 4 || e.SocketError != SocketError.Success)
            {
                Disconnect(e.SocketError);

                e.Completed -= TcpHeaderReceiveCompleted;
                ObjectCache.ReturnSocketAsyncEventArgs(e);

                return;
            }

            if (e.Offset + e.BytesTransferred < e.Buffer.Length)
            {
                e.SetBuffer(e.Buffer, e.Offset + e.BytesTransferred, e.Buffer.Length - e.Offset - e.BytesTransferred);
                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpHeaderReceiveCompleted(this, e);
            }
            else
            {
                int length = BigEndianHelper.ReadInt32(e.Buffer, 0);

                MessageBuffer buffer = MessageBuffer.Create(length);
                buffer.Count = length;

                e.SetBuffer(buffer.Buffer, buffer.Offset, length);
                e.UserToken = buffer;
                e.Completed -= TcpHeaderReceiveCompleted;
                e.Completed += TcpBodyReceiveCompleted;

                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpBodyReceiveCompleted(this, e);
            }
        }

        /// <summary>
        ///     Called when the body of a TCP message is received.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TcpBodyReceiveCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.BytesTransferred == 0 || e.SocketError != SocketError.Success)
            {
                Disconnect(e.SocketError);

                e.Completed -= TcpBodyReceiveCompleted;
                ObjectCache.ReturnSocketAsyncEventArgs(e);

                return;
            }

            //Check we've received all the message
            if (e.Offset + e.BytesTransferred < e.Buffer.Length)
            {
                e.SetBuffer(e.Buffer, e.Offset + e.BytesTransferred, e.Buffer.Length - e.Offset - e.BytesTransferred);
                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpBodyReceiveCompleted(this, e);
            }
            else
            {
                byte[] data = e.Buffer;

                e.SetBuffer(new byte[4], 0, 4);
                e.Completed -= TcpBodyReceiveCompleted;
                e.Completed += TcpHeaderReceiveCompleted;

                bool completingAsync = tcpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    TcpHeaderReceiveCompleted(this, e);

                MessageBuffer buffer = (MessageBuffer)e.UserToken;

                HandleMessageReceived(buffer, SendMode.Reliable);

                //Cleanup
                buffer.Dispose();
            }
        }

        /// <summary>
        ///     Called when a UDP message arrives.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UdpReceiveCompleted(object sender, SocketAsyncEventArgs e)
        {
            //If we received a Success then process it
            if (e.SocketError == SocketError.Success)
            {
                using (MessageBuffer buffer = MessageBuffer.Create(e.BytesTransferred))
                {
                    Buffer.BlockCopy(e.Buffer, 0, buffer.Buffer, buffer.Offset, e.BytesTransferred);
                    buffer.Count = e.BytesTransferred;

                    bool completingAsync = udpSocket.ReceiveAsync(e);
                    if (!completingAsync)
                        UdpReceiveCompleted(this, e);

                    //Length of 0 must be a hole punching packet
                    if (buffer.Count != 0)
                        HandleMessageReceived(buffer, SendMode.Unreliable);
                }
            }

            //Ignore ConnectionReset (ICMP Port Unreachable) since NATs will return that when they get 
            //the punchthrough packets and they've not already been opened
            else if (e.SocketError == SocketError.ConnectionReset)
            {
                bool completingAsync = udpSocket.ReceiveAsync(e);
                if (!completingAsync)
                    UdpReceiveCompleted(this, e);
            }

            //Anything else is probably bad news
            else
            {
                Disconnect(e.SocketError);

                e.Completed -= UdpReceiveCompleted;
                ObjectCache.ReturnSocketAsyncEventArgs(e);
            }
        }

        /// <summary>
        ///     Called when a TCP send has completed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void TcpSendCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.SocketError != SocketError.Success)
                Disconnect(e.SocketError);

            e.Completed -= TcpSendCompleted;

            //Always dispose buffer when completed!
            ((MessageBuffer)e.UserToken).Dispose();

            ObjectCache.ReturnSocketAsyncEventArgs(e);
        }

        /// <summary>
        ///     Called when a UDP send has completed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void UdpSendCompleted(object sender, SocketAsyncEventArgs e)
        {
            if (e.SocketError != SocketError.Success)
                Disconnect(e.SocketError);

            e.Completed -= UdpSendCompleted;

            //Always dispose buffer when completed!
            ((MessageBuffer)e.UserToken).Dispose();

            ObjectCache.ReturnSocketAsyncEventArgs(e);
        }

        /// <summary>
        ///     Called when a socket error has occured.
        /// </summary>
        /// <param name="error">The error causing the disconnect.</param>
        private void Disconnect(SocketError error)
        {
            if (connectionState == ConnectionState.Connected)
            {
                connectionState = ConnectionState.Disconnected;

                HandleDisconnection(error);
            }
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected override void Dispose(bool disposing)
        {
            base.Dispose(true);

            if (!disposedValue)
            {
                if (disposing)
                {
                    Disconnect();

                    tcpSocket.Close();
                    udpSocket.Close();
                }

                disposedValue = true;
            }
        }
        #endregion
    }
}
