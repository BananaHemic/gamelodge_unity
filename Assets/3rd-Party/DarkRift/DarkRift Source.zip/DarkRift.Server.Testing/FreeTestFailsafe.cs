﻿#if !PRO
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DarkRift.Server.Testing
{
    [TestClass]
    class FreeTestFailsafe
    {
        [TestMethod]
        public void StopUsingFreeVersionToTest()
        {
            Assert.Fail("Don't use the free version to test, not all tests will be run in the free version!");
        }
    }
}
#endif