﻿#if PRO
using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Text.RegularExpressions;
using DarkRift.Server.Plugins.Chat;
using System.Collections.Specialized;
using DarkRift.Server;
using System.IO;

namespace DarkRift.Testing.UnitTests.UnitTests
{
    [TestClass]
    public class BadWordFilterTests
    {
        /*
         * ~~~ Here Be Swear Words ~~~
         */

        //Please dont be offended...


        [TestMethod]
        public void BadWordFilterTest()
        {
            BadWordFilter filter = new BadWordFilter(new PluginLoadData("BadWordFilter", new NameValueCollection(), new DarkRiftInfo(DateTime.Now), new DarkRiftThreadHelper(false, null), null, Path.GetTempPath()));

            //Cheat and use a set list of words here
            filter.PopulateBadWords(new string[] { "fuck", "shit" });

            Assert.IsTrue(filter.ContainsBadWords("Fuck"));

            Assert.AreEqual("You smell like ~~~~.", filter.FilterToChar("You smell like shit.", '~'));

            Assert.IsTrue(Regex.IsMatch(filter.FilterToSymbols("Fuck you."), @"^[\$#@%&\*!]{4} you."));

            string a = filter.FilterToRandomString("Shit's going down.", new string[] { "Australia", "Gravity" });
            Assert.IsTrue(a == "Australia's going down." || a == "Gravity's going down.");
        }
    }
}
#endif