﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     Command codes for control sequences to clients/servers.
    /// </summary>
    internal enum CommandCode : ushort
    {
        /// <summary>
        ///     A configuration packet to a client.
        /// </summary>
        Configure = 0,              //                  [ID, ID, ID, ID]

        /// <summary>
        ///     A new client was assigned to the server.
        /// </summary>
        ClientAssign = 1         //                     [ID, ID, ID, ID]
    }
}
