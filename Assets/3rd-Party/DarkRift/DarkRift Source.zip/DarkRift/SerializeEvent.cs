﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     DEscribes the serialization in progress.
    /// </summary>
    public class SerializeEvent
    {
        /// <summary>
        ///     The writer to write the object data to.
        /// </summary>
        public DarkRiftWriter Writer { get; }

        internal SerializeEvent(DarkRiftWriter writer)
        {
            Writer = writer;
        }
    }
}
