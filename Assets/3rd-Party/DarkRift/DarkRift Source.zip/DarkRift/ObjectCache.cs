﻿using DarkRift.Dispatching;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace DarkRift
{
    /// <summary>
    ///     A cache of DarkRift objects for recycling.
    /// </summary>
    /// <remarks>
    ///     Must be initialized on the thread using DarkRiftServer.InitializeObjectCache() or will throw errors.
    /// </remarks>
    internal static class ObjectCache
    {
        /// <summary>
        ///     Whether this cache has been initialized yet.
        /// </summary>
        [ThreadStatic]
        static bool initialized;

        /// <summary>
        ///     Object pool of DarkRiftWriters.
        /// </summary>
        [ThreadStatic]
        static ObjectPool<DarkRiftWriter> writerPool;

        /// <summary>
        ///     Object pool of DarkRiftReaders.
        /// </summary>
        [ThreadStatic]
        static ObjectPool<DarkRiftReader> readerPool;

        /// <summary>
        ///     Object pool of Messages.
        /// </summary>
        [ThreadStatic]
        static ObjectPool<Message> messagePool;

        /// <summary>
        ///     Object pool of SocketAsyncEventArgs.
        /// </summary>
        [ThreadStatic]
        static ObjectPool<SocketAsyncEventArgs> socketAsyncEventArgsPool;

        /// <summary>
        ///     Object pool of ActionDispatcherTasks.
        /// </summary>
        [ThreadStatic]
        static ObjectPool<ActionDispatcherTask> actionDispatcherTaskPool;


        /// <summary>
        ///     The settings for all object caches.
        /// </summary>
        static ObjectCacheSettings settings;

        /// <summary>
        ///     The lock for the settings field.
        /// </summary>
        static readonly object settingsLock = new object();

        /// <summary>
        ///     Sets up the ObjectCache with the given settings.
        /// </summary>
        /// <returns>True if the object cache was set with the sepcified settings, false if it is already initialized.</returns>
        public static bool Initialize(ObjectCacheSettings settings)
        {
            lock (settingsLock)
            {
                if (ObjectCache.settings == null)
                {
                    ObjectCache.settings = settings;
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        ///     Initializes the object cache with the stored settings.
        /// </summary>
        static void ThreadInitialize()
        {
            lock (settingsLock)
            {
                writerPool = new ObjectPool<DarkRiftWriter>(settings.MaxWriters, () => new DarkRiftWriter());
                readerPool = new ObjectPool<DarkRiftReader>(settings.MaxReaders, () => new DarkRiftReader());
                messagePool = new ObjectPool<Message>(settings.MaxMessages, () => new Message());
                socketAsyncEventArgsPool = new ObjectPool<SocketAsyncEventArgs>(settings.MaxSocketAsyncEventArgs, () => new SocketAsyncEventArgs());
                actionDispatcherTaskPool = new ObjectPool<ActionDispatcherTask>(settings.MaxActionDispatcherTasks, () => new ActionDispatcherTask());
            }

            initialized = true;
        }
        
        /// <summary>
        ///     Returns a pooled DarkRiftWriter or generates a new one if there are none available.
        /// </summary>
        /// <returns>A free DarkRiftWriter.</returns>
        public static DarkRiftWriter GetWriter()
        {
            if (!initialized)
                ThreadInitialize();

            return writerPool.GetInstance();
        }

        /// <summary>
        ///     Returns a used DarkRiftWriter to the pool.
        /// </summary>
        /// <param name="writer">The DarkRiftWriter to return.</param>
        public static void ReturnWriter(DarkRiftWriter writer)
        {
            if (!initialized)
                ThreadInitialize();

            writerPool.ReturnInstance(writer);
        }

        /// <summary>
        ///     Returns a pooled DarkRiftReader or generates a new one if there are none available.
        /// </summary>
        /// <returns>A free DarkRiftReader.</returns>
        public static DarkRiftReader GetReader()
        {
            if (!initialized)
                ThreadInitialize();

            return readerPool.GetInstance();
        }

        /// <summary>
        ///     Returns a used DarkRiftReader to the pool.
        /// </summary>
        /// <param name="reader">The DarkRifReader to return.</param>
        public static void ReturnReader(DarkRiftReader reader)
        {
            if (!initialized)
                ThreadInitialize();

            readerPool.ReturnInstance(reader);
        }

        /// <summary>
        ///     Returns a pooled Message or generates a new one if there are none available.
        /// </summary>
        /// <returns>A free Message.</returns>
        public static Message GetMessage()
        {
            if (!initialized)
                ThreadInitialize();

            return messagePool.GetInstance();
        }

        /// <summary>
        ///     Returns a used Message to the pool.
        /// </summary>
        /// <param name="message">The Message to return.</param>
        public static void ReturnMessage(Message message)
        {
            if (!initialized)
                ThreadInitialize();

            messagePool.ReturnInstance(message);
        }

        /// <summary>
        ///     Returns a pooled SocketAsyncEventArgs object or generates a new one if there are none available.
        /// </summary>
        /// <returns>A free SocketAsyncEventArgs object.</returns>
        public static SocketAsyncEventArgs GetSocketAsyncEventArgs()
        {
            if (!initialized)
                ThreadInitialize();

            return socketAsyncEventArgsPool.GetInstance();
        }

        /// <summary>
        ///     Returns a used SocketAsyncEventArgs object to the pool or disposes of it if there are already enough.
        /// </summary>
        /// <param name="socketAsyncEventArgs">The SocketAsyncEventArgs object to return.</param>
        public static void ReturnSocketAsyncEventArgs(SocketAsyncEventArgs socketAsyncEventArgs)
        {
            if (!initialized)
                ThreadInitialize();

            if (!socketAsyncEventArgsPool.ReturnInstance(socketAsyncEventArgs))
                socketAsyncEventArgs.Dispose();
        }

        /// <summary>
        ///     Returns a pooled ActionDispatcherTask or generates a new one if there are none available.
        /// </summary>
        /// <returns>A free ActionDispatcherTask.</returns>
        public static ActionDispatcherTask GetActionDispatcherTask()
        {
            if (!initialized)
                ThreadInitialize();

            return actionDispatcherTaskPool.GetInstance();
        }

        /// <summary>
        ///     Returns a used ActionDispatcherTask to the pool.
        /// </summary>
        /// <param name="task">The ActionDispatcherTask to return.</param>
        public static void ReturnActionDispatcherTask(ActionDispatcherTask task)
        {
            if (!initialized)
                ThreadInitialize();

            if (!actionDispatcherTaskPool.ReturnInstance(task))
                task.ActuallyDispose();
        }
    }
}
