﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     Describes the deserialization in progress.
    /// </summary>
    public class DeserializeEvent
    {
        /// <summary>
        ///     The reader to read the data from.
        /// </summary>
        public DarkRiftReader Reader { get; }

        internal DeserializeEvent(DarkRiftReader reader)
        {
            Reader = reader;
        }
    }
}
