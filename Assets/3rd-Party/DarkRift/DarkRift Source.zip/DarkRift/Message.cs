﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     Message class for all messages sent through DarkRift.
    /// </summary>
    /// <remarks>
    ///     Since each message is handled by single, separate threads this class is not thread safe.
    /// </remarks>
    public sealed class Message : IDisposable
    {
        /// <summary>
        ///     Bitmask for the command message flag.
        /// </summary>
        const byte COMMAND_FLAG_MASK = 0b10000000;
        
        /// <summary>
        ///     The data buffer received.
        /// </summary>
        /// <remarks>
        ///     WARNING! Modifying the data in this buffer will alter the data of all clones of this message! Only ever change the reference!
        /// </remarks>
        byte[] buffer;

        /// <summary>
        ///     The offset of data in the buffer.
        /// </summary>
        int dataOffset;

        /// <summary>
        ///     The number of bytes of data in this message.
        /// </summary>
        public int DataLength { get; private set; }

        /// <summary>
        ///     Are setters on this object disabled?
        /// </summary>
        public bool IsReadOnly { get; private set; }

        /// <summary>
        ///     Indicates whether this message is a command message or not.
        /// </summary>
        internal bool IsCommandMessage
        {
            get
            {
                return (flags & COMMAND_FLAG_MASK) != 0;
            }

            set
            {
                if (value)
                    flags |= COMMAND_FLAG_MASK;
                else
                    flags &= byte.MaxValue ^ COMMAND_FLAG_MASK;        //XOR over simple bitwise NOT to avoid entering negative values and ints!
            }
        }

        /// <summary>
        ///     The flags attached to this message.
        /// </summary>
        /// <remarks>
        ///     8th bit - Command
        ///     7th bit - Not used
        ///     6th bit - Not used
        ///     5th bit - Not used
        ///     4th bit - Not used
        ///     3rd bit - Not used
        ///     2nd bit - Not used
        ///     1st bit - Not used
        /// </remarks>
        byte flags;

        /// <summary>
        ///     The tag of the message.
        /// </summary>
        public ushort Tag
        {
            get
            {
                return tag;
            }

            set
            {
                if (IsReadOnly)
                    throw new AccessViolationException("Message is read-only.");
                else
                    tag = value;
            }
        }

        ushort tag;

        /// <summary>
        ///     Creates a new message with the given tag and a null payload.
        /// </summary>
        /// <param name="tag">The tag the message has.</param>
        public static Message CreateEmpty(ushort tag)
        {
            Message message = ObjectCache.GetMessage();
            message.Empty();
            message.tag = tag;
            return message;
        }

        /// <summary>
        ///     Creates a new message with the given tag and writer.
        /// </summary>
        /// <param name="tag">The tag the message has.</param>
        /// <param name="writer">The initial data in the message.</param>
        public static Message Create(ushort tag, DarkRiftWriter writer)
        {
            Message message = ObjectCache.GetMessage();
            message.Serialize(writer);
            message.tag = tag;
            message.flags = 0;
            return message;
        }

        /// <summary>
        ///     Creates a new message with the given tag and serializable object.
        /// </summary>
        /// <param name="tag">The tag the message has.</param>
        /// <param name="obj">The initial object in the message data.</param>
        public static Message Create(ushort tag, IDarkRiftSerializable obj)
        {
            Message message = ObjectCache.GetMessage();
            message.Serialize(obj);
            message.tag = tag;
            message.flags = 0;
            return message;
        }

        /// <summary>
        ///     Creates a new message from the given buffer.
        /// </summary>
        /// <param name="buffer">The buffer containing the message.</param>
        /// <param name="isReadOnly">Whether the message should be created read only or not.</param>
        internal static Message Create(MessageBuffer buffer, bool isReadOnly)
        {
            Message message = ObjectCache.GetMessage();

            message.buffer = buffer.Buffer;
            message.dataOffset = buffer.Offset + 3;
            message.DataLength = buffer.Count - message.dataOffset;
            message.IsReadOnly = isReadOnly;

            message.flags = buffer.Buffer[buffer.Offset];
            message.tag = BigEndianHelper.ReadUInt16(buffer.Buffer, buffer.Offset + 1);
            return message;
        }

        /// <summary>
        ///     Creates a new Message. For use from the ObjectCache.
        /// </summary>
        internal Message()
        {

        }

        /// <summary>
        ///     Clears the data in this message.
        /// </summary>
        public void Empty()
        {
            if (IsReadOnly)
                throw new AccessViolationException("Message is read-only.");

            this.buffer = new byte[0];
            this.DataLength = 0;
            this.dataOffset = 0;
        }

        /// <summary>
        ///     Creates a DarkRiftReader to read the data in the message.
        /// </summary>
        /// <returns>A DarkRiftReader for the message.</returns>
        public DarkRiftReader GetReader()
        {
            return DarkRiftReader.Create(buffer, dataOffset, DataLength);
        }
        
        /// <summary>
        ///     Serializes a <see cref="DarkRiftWriter"/> into the data of this message.
        /// </summary>
        /// <param name="writer">The writer to serialize.</param>
        public void Serialize(DarkRiftWriter writer)
        {
            if (IsReadOnly)
                throw new AccessViolationException("Message is read-only.");

            //Warning! Never, ever modify the contents of buffer otherwise all clones will change. Just change the reference.
            
            this.buffer = writer.Data;
            this.DataLength = writer.Length;
            this.dataOffset = 0;
        }

        /// <summary>
        ///     Deserializes the data to the given object.
        /// </summary>
        /// <typeparam name="T">The type of object to deserialize to.</typeparam>
        /// <returns>The deserialized object.</returns>
        public T Deserialize<T>() where T : IDarkRiftSerializable, new()
        {
            return GetReader().ReadSerializable<T>();
        }

        /// <summary>
        ///     Serializes an object into the data of this message.
        /// </summary>
        /// <param name="obj">The object to serialize.</param>
        public void Serialize(IDarkRiftSerializable obj)
        {
            if (IsReadOnly)
                throw new AccessViolationException("Message is read-only.");

            using (DarkRiftWriter writer = DarkRiftWriter.Create())
            {
                writer.Write(obj);

                Serialize(writer);
            }
        }

        /// <summary>
        ///     Converts this message into a buffer.
        /// </summary>
        /// <returns>The buffer.</returns>
        internal MessageBuffer ToBuffer()
        {
            MessageBuffer buffer = MessageBuffer.Create(3 + DataLength);
            buffer.Count = 3 + DataLength;

            buffer.Buffer[buffer.Offset] = flags;
            BigEndianHelper.WriteBytes(buffer.Buffer, buffer.Offset + 1, tag);
            Buffer.BlockCopy(this.buffer, this.dataOffset, buffer.Buffer, buffer.Offset + 3, DataLength);

            return buffer;
        }

        /// <summary>
        ///     Performs a shallow copy of the message.
        /// </summary>
        /// <returns>A new instance of the message.</returns>
        public Message Clone()
        {
            Message message = ObjectCache.GetMessage();
            message.buffer = buffer;
            message.dataOffset = dataOffset;
            message.DataLength = DataLength;
            message.tag = tag;
            return message;
        }

        /// <inheritdoc />
        public override string ToString()
        {
            return $"Message with tag '{Tag}' and {DataLength} bytes of data.";
        }

        /// <summary>
        ///     Recycles this object back into the pool.
        /// </summary>
        public void Dispose()
        {
            ObjectCache.ReturnMessage(this);
        }
    }
}
