﻿using System;

namespace DarkRift
{
    /// <summary>
    ///     Holds raw data related to a message.
    /// </summary>
    public sealed class MessageBuffer : IDisposable
    {
        /// <summary>
        ///     The array containing the data.
        /// </summary>
        /// <remarks>
        ///     You should only ever access the buffer in the region defined by 
        ///     <see cref="Offset"/> and <see cref="Count"/> else you may read/write over other data.
        /// </remarks>
        public byte[] Buffer { get; }

        /// <summary>
        ///     The offset of data in the array.
        /// </summary>
        public int Offset { get; set; }

        /// <summary>
        ///     The number of bytes of data in the array.
        /// </summary>
        public int Count { get; set; }

        /// <summary>
        ///     Creates a new message buffer for an array.
        /// </summary>
        /// <param name="buffer">The array to wrap.</param>
        MessageBuffer(byte[] buffer)
        {
            this.Buffer = buffer;
        }

        /// <summary>
        ///     Creates a new message buffer with a given minimum size.
        /// </summary>
        /// <param name="minSize">The minimum number of bytes in the buffer.</param>
        /// <returns>The new message buffer.</returns>
        public static MessageBuffer Create(int minSize)
        {
            MessageBuffer buffer = new MessageBuffer(new byte[minSize]);
            buffer.Offset = 0;
            buffer.Count = 0;

            return buffer;
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //Decrement buffer count here, potentially recycle!
                }
                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }
        #endregion
    }
}