﻿namespace DarkRift.Dispatching
{
    public delegate void ActionDispatchCompleteCallback(ActionDispatcherTask task);
}