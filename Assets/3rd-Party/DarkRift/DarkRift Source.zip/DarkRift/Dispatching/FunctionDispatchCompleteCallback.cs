﻿namespace DarkRift.Dispatching
{
    public  delegate void FunctionDispatchCompleteCallback<T>(FunctionDispatcherTask<T> task);
}