﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace DarkRift.Dispatching
{
    /// <summary>
    ///     A <see cref="DispatcherTask"/> that has no return value.
    /// </summary>
    public class ActionDispatcherTask : DispatcherTask
    {
        /// <summary>
        ///     The action to execute.
        /// </summary>
        Action Action;
        
        /// <summary>
        ///     The callback to invoke once the task has been executed.
        /// </summary>
        ActionDispatchCompleteCallback Callback;

        /// <summary>
        ///     Creates an ActionDispatcherTask.
        /// </summary>
        internal ActionDispatcherTask() : base()
        {

        }

        /// <summary>
        ///     Creates a new action dispatcher task.
        /// </summary>
        /// <param name="action">The action to execute.</param>
        internal static ActionDispatcherTask Create(Action action)
        {
            return Create(action, null);
        }

        /// <summary>
        ///     Creates a new action dispatcher task.
        /// </summary>
        /// <param name="action">The action to execute.</param>
        internal static ActionDispatcherTask Create(Action action, ActionDispatchCompleteCallback callback)
        {
            ActionDispatcherTask task = ObjectCache.GetActionDispatcherTask();
            task.Action = action;
            task.Callback = callback;

            return task;
        }

        /// <summary>
        ///     Executes the action.
        /// </summary>
        /// <param name="synchronous">Was this called synchronously?</param>
        internal override void Execute(bool synchronous)
        {
            try
            {
                Action.Invoke();
            }
            catch (Exception e)
            {
                SetTaskFailed(e);
                throw new DispatcherException("An exception occurred whilst running a distaptcher task. See inner exception for more details.", e);
            }

            SetTaskComplete(synchronous);

            if (Callback != null)
            {
                if (synchronous)
                    Callback(this);
                else
                    ThreadPool.QueueUserWorkItem((_) => Callback(this));
            }
        }
        
        /// <summary>
        ///     Actually disposes of the instance rather than recycling it.
        /// </summary>
        internal void ActuallyDispose()
        {
            base.Dispose(true);
        }

        protected override void Dispose(bool disposing)
        {
            //Intercepts default dispose to recycle the instance!

            ObjectCache.ReturnActionDispatcherTask(this);
        }
    }
}
