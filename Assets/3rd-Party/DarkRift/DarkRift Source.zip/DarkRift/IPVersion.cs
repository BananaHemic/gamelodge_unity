﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     IP addressing modes.
    /// </summary>
    public enum IPVersion
    {
        /// <summary>
        ///     Indicates IPv4 is in use/should be used.
        /// </summary>
        IPv4,

        /// <summary>
        ///     Indicates IPv6 is in user/should be used.
        /// </summary>
        IPv6
    }
}
