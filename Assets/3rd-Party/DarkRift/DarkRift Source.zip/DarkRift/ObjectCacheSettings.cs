﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DarkRift
{
    /// <summary>
    ///     Configuration for the <see cref="ObjectCache"/>.
    /// </summary>
    internal class ObjectCacheSettings
    {
        /// <summary>
        ///     The maximum number of DarkRiftWriters to cache per thread.
        /// </summary>
        public int MaxWriters { get; set; }

        /// <summary>
        ///     The maximum number of DarkRiftReaders to cache per thread.
        /// </summary>
        public int MaxReaders { get; set; }

        /// <summary>
        ///     The maximum number of Messages to cache per thread.
        /// </summary>
        public int MaxMessages { get; set; }

        /// <summary>
        ///     The maximum number of SocketAsyncEventArgs to cache per thread.
        /// </summary>
        public int MaxSocketAsyncEventArgs { get; set; }

        /// <summary>
        ///     The maximum number of ActionDisapatcherTasks to cache per thread.
        /// </summary>
        public int MaxActionDispatcherTasks { get; set; }

        /// <summary>
        ///     Return settings so no objects are cached.
        /// </summary>
        public static readonly ObjectCacheSettings DontUseCache = new ObjectCacheSettings(0, 0, 0, 0, 0);

        /// <summary>
        ///     Creates a new configuration for the <see cref="ObjectCache"/>.
        /// </summary>
        /// <param name="maxWriters">The maximum number of DarkRiftWriters to cache per thread.</param>
        /// <param name="maxReaders">The maximum number of DarkRiftReaders to cache per thread.</param>
        /// <param name="maxMessages">The maximum number of Messages to cache per thread.</param>
        /// <param name="maxSocketAsyncEventArgs">The maximum number of SocketAsyncEventArgs to cache per thread.</param>
        /// <param name="maxActionDispatcherTasks">The maximum number of ActionDispatcherTasks to cache per thread.</param>
        public ObjectCacheSettings(int maxWriters, int maxReaders, int maxMessages, int maxSocketAsyncEventArgs, int maxActionDispatcherTasks)
        {
            MaxWriters = maxWriters;
            MaxReaders = maxReaders;
            MaxMessages = maxMessages;
            MaxSocketAsyncEventArgs = maxSocketAsyncEventArgs;
        }
    }
}
